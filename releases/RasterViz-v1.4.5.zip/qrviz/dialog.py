import os
import uuid
import numpy as np

# ── Basemap engine ───────────────────────────────────────────────────────────
# Raster and vector reading are 100% QGIS-native (see raster_io.py /
# vector_io.py), and so is the web basemap layer (see basemap_io.py): it
# builds a native QgsRasterLayer XYZ connection and renders it through
# QGIS's own map-render pipeline, the same way QuickMapServices draws its
# TMS layers. No third-party packages are required for any of it.
from .basemap_io import render_basemap_to_array

from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGroupBox,
    QLabel, QComboBox, QCheckBox, QPushButton,
    QDoubleSpinBox, QSpinBox, QFileDialog, QSizePolicy,
    QWidget, QRadioButton, QButtonGroup, QGridLayout,
    QLineEdit, QTabWidget, QScrollArea, QMessageBox, QSplitter,
    QColorDialog, QFrame, QListWidget, QListWidgetItem, QAbstractItemView,
    QMenu, QProgressBar
)
from qgis.PyQt.QtGui import QFontDatabase, QPixmap, QPainter, QColor, QFont, QDesktopServices
from qgis.PyQt.QtCore import Qt, QUrl, QSize, QTimer
from qgis.core import QgsCoordinateReferenceSystem, QgsRectangle, QgsMessageLog, Qgis

from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib
import matplotlib.ticker as mticker
import matplotlib.patches as mpatches

from .colormaps import COLORMAPS
from .raster_io import RASTER_REGISTRY, RasterLayer, SUPPORTED_RASTER_FILTER, Extent
from .vector_io import (
    VectorLayer, DEFAULT_PALETTE, SUPPORTED_VECTOR_FILTER,
    render_vector_layer, crs_display_string, make_coordinate_transform,
)


def create_groupbox(title):
    gb = QGroupBox(title)
    f = gb.font()
    f.setBold(True)
    gb.setFont(f)
    return gb

def _stacked_pair(w1, label1, w2, label2):
    """Lay two small widgets (e.g. an X/Y or Width/Height pair) out one
    per line instead of side-by-side, so a grid cell only ever needs to be
    as wide as a single control — keeps the narrow right-hand panel from
    truncating labels."""
    lay = QVBoxLayout()
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(3)
    for w, lbl in ((w1, label1), (w2, label2)):
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(4)
        lbl_w = QLabel(lbl)
        lbl_w.setFixedWidth(16)
        row.addWidget(lbl_w)
        row.addWidget(w)
        lay.addLayout(row)
    return lay

def _style_kwargs(bold_checked, italic_checked):
    """Return matplotlib fontweight/fontstyle kwargs for a Bold+Italic checkbox pair."""
    return {
        "fontweight": "bold" if bold_checked else "normal",
        "fontstyle": "italic" if italic_checked else "normal",
    }

def _haversine_m(lon1, lat1, lon2, lat2):
    """Great-circle distance in metres between two lon/lat points (degrees)."""
    R = 6371000.0
    p1, p2 = np.radians(lat1), np.radians(lat2)
    dphi = np.radians(lat2 - lat1)
    dlmb = np.radians(lon2 - lon1)
    a = np.sin(dphi / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dlmb / 2) ** 2
    return R * 2 * np.arcsin(np.sqrt(a))

# VectorLayer now lives in vector_io.py (QGIS-native, backed by
# QgsVectorLayer/OGR instead of geopandas/fiona) and is imported above.

class DiscreteClassRow(QWidget):
    # Shared with vector categorized symbology — see vector_io.DEFAULT_PALETTE.
    DEFAULT_PALETTE = DEFAULT_PALETTE

    def __init__(self, gridcode, color_hex=None, label="", decimals=2, parent=None):
        super().__init__(parent)
        self.gridcode = gridcode
        self._color = color_hex or "#888888"

        row = QHBoxLayout(self)
        row.setContentsMargins(2, 2, 2, 2)
        row.setSpacing(6)

        self.btn_color = QPushButton()
        self.btn_color.setFixedSize(26, 26)
        self.btn_color.clicked.connect(self._pick_color)
        self._apply_color_style()
        row.addWidget(self.btn_color)

        self.le_hex = QLineEdit(self._color)
        self.le_hex.setFixedWidth(72)
        self.le_hex.textChanged.connect(self._on_hex_changed)
        row.addWidget(self.le_hex)

        lbl_val = QLabel(f"<b>{gridcode}</b>")
        lbl_val.setFixedWidth(46)
        lbl_val.setAlignment(Qt.AlignCenter)
        row.addWidget(lbl_val)

        row.addWidget(QLabel("Label:"))
        self.le_label = QLineEdit(label if label else str(gridcode))
        self.le_label.setMinimumWidth(80)
        row.addWidget(self.le_label, stretch=1)

        row.addWidget(QLabel("Dec:"))
        self.sp_decimals = QSpinBox()
        self.sp_decimals.setRange(0, 6)
        self.sp_decimals.setValue(decimals)
        self.sp_decimals.setFixedWidth(46)
        row.addWidget(self.sp_decimals)

    def _apply_color_style(self):
        c = QColor(self._color)
        if c.isValid():
            luma = 0.299 * c.red() + 0.587 * c.green() + 0.114 * c.blue()
            txt = "#000000" if luma > 160 else "#ffffff"
            self.btn_color.setStyleSheet(f"background-color:{self._color}; color:{txt}; border:1px solid #888; border-radius:3px; font-size:9px;")
        else:
            self.btn_color.setStyleSheet("background-color:#888888; border:1px solid #888; border-radius:3px;")

    def _pick_color(self):
        initial = QColor(self._color) if QColor(self._color).isValid() else QColor("#888888")
        col = QColorDialog.getColor(initial, self, f"Choose Colour — Class {self.gridcode}")
        if col.isValid():
            self._color = col.name()
            self._apply_color_style()
            self.le_hex.blockSignals(True)
            self.le_hex.setText(self._color)
            self.le_hex.blockSignals(False)

    def _on_hex_changed(self, text):
        t = text.strip()
        if not t.startswith("#"): t = "#" + t
        c = QColor(t)
        if c.isValid():
            self._color = c.name()
            self._apply_color_style()

    def get_color(self):
        c = QColor(self._color)
        return self._color if c.isValid() else "#888888"

    def get_label(self):
        return self.le_label.text().strip() or str(self.gridcode)

    def get_decimals(self):
        return self.sp_decimals.value()


class VectorCategoryRow(QWidget):
    def __init__(self, value, color_hex=None, parent=None):
        super().__init__(parent)
        self.value = value
        self._color = color_hex or "#888888"

        row = QHBoxLayout(self)
        row.setContentsMargins(2, 2, 2, 2)
        row.setSpacing(6)

        self.btn_color = QPushButton()
        self.btn_color.setFixedSize(24, 24)
        self.btn_color.clicked.connect(self._pick_color)
        self._apply_color_style()
        row.addWidget(self.btn_color)

        lbl = QLabel(str(value))
        lbl.setWordWrap(True)
        row.addWidget(lbl, stretch=1)

    def _apply_color_style(self):
        c = QColor(self._color)
        if not c.isValid():
            c = QColor("#888888")
            self._color = c.name()
        self.btn_color.setStyleSheet(f"background-color:{self._color}; border:1px solid #888; border-radius:3px;")

    def _pick_color(self):
        initial = QColor(self._color) if QColor(self._color).isValid() else QColor("#888888")
        col = QColorDialog.getColor(initial, self, f"Choose Colour — {self.value}")
        if col.isValid():
            self._color = col.name()
            self._apply_color_style()

    def get_color(self):
        return self._color


class QRVIZDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowFlags(Qt.Window)
        self.setWindowTitle("RasterViz - GIS Edition")
        self.setMinimumSize(1400, 820)

        # No custom font is forced here — the dialog inherits whatever font
        # Qt/QGIS is already using, so it follows the user's QGIS/OS setup
        # automatically instead of hunting for a specific font family.

        self._layers_dict = {}
        self._map_cache = {}
        # Cache of (image_array, extent) already rendered by basemap_io,
        # keyed by (provider, crs, view bounds). Most control tweaks
        # (title text, font size, decimals, ...) trigger a full re-render
        # but don't touch the basemap at all — without this, every one of
        # those re-renders the basemap tiles from scratch.
        self._basemap_cache = {}
        
        self._cached_arr = None
        self._cached_rgb = None
        self._cached_ext = None
        self._cached_crs = None
        self._is_updating = False
        self._discrete_rows = []
        self._nodata_color = "#00000000"
        self._colorbar_drawn = False
        self._view_ext = None
        self._current_vector_lid = None
        self._vec_category_rows = []
        # Set by _apply_canvas_size() when a fixed paper size (A4, A3, ...)
        # is applied; None means "fit to window" (the original dynamic
        # sizing behaviour).
        self._canvas_fixed_size_in = None

        # Rapid-fire UI events (holding a spinbox arrow, dragging a
        # position field, typing in a label) each call _trigger_live_update.
        # Redrawing the whole figure synchronously on every single one of
        # those made the UI feel heavy under normal use; this timer
        # coalesces bursts of triggers into a single re-render ~120ms after
        # the user stops interacting.
        self._update_timer = QTimer(self)
        self._update_timer.setSingleShot(True)
        self._update_timer.setInterval(120)
        self._update_timer.timeout.connect(self._live_update)

        self._build_ui()
        self._connect_live_updates()
        self.showMaximized()

    def _build_ui(self):
        # Consistent sizing/spacing for every control so the panels stay
        # comfortable to use regardless of QGIS's active theme — no colours
        # are touched here, only padding/heights (see class docstring notes
        # elsewhere in this file about following the QGIS theme).
        self.setStyleSheet("""
            QGroupBox { font-weight: bold; margin-top: 12px; padding-top: 8px; }
            QGroupBox::title { subcontrol-origin: margin; left: 8px; padding: 0 4px; }
            QComboBox, QLineEdit, QSpinBox, QDoubleSpinBox { min-height: 22px; padding: 1px 4px; }
            QPushButton { min-height: 26px; padding: 3px 12px; }
            QTabBar::tab { padding: 6px 12px; }
            QListWidget { min-height: 24px; }
            #panelRight QComboBox, #panelRight QLineEdit,
            #panelRight QSpinBox, #panelRight QDoubleSpinBox { max-width: 185px; }
        """)

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(12, 12, 12, 12)
        main_layout.setSpacing(12)

        # -------------------------------------------------------------
        # HEADER (text only — no logo/icon)
        # -------------------------------------------------------------
        hdr = QHBoxLayout()
        hdr.setSpacing(10)

        lbl_title = QLabel("RasterViz")
        f = self.font()
        f.setPointSize(16)
        f.setBold(True)
        lbl_title.setFont(f)
        hdr.addWidget(lbl_title)
        hdr.addStretch()

        self.btn_global_export = QPushButton("Export")
        self.btn_global_export.setObjectName("btnPrimary")
        self.btn_global_export.setMinimumHeight(32)
        f_btn = self.btn_global_export.font()
        f_btn.setBold(True)
        self.btn_global_export.setFont(f_btn)
        self.btn_global_export.clicked.connect(self.export_figure)
        hdr.addWidget(self.btn_global_export)

        main_layout.addLayout(hdr)

        self.main_splitter = QSplitter(Qt.Horizontal)
        self.main_splitter.setHandleWidth(8)

        # -------------------------------------------------------------
        # RIGHT PANEL (created early: Data && Layers tabs are built and
        # added to it right below, before the map canvas — there is no
        # left panel any more, so the map gets all of that space instead)
        # -------------------------------------------------------------
        self.tab_right = QTabWidget()
        self.tab_right.setObjectName("panelRight")
        self.tab_right.setMinimumWidth(240)
        self.tab_right.setTabPosition(QTabWidget.East)
        # Geometry-only rule (no colors) so the East-side tab strip hugs its
        # text label instead of the style's default wide padding — colors
        # still come entirely from the active Qt/QGIS palette.
        self.tab_right.setStyleSheet("QTabBar::tab { padding: 8px 10px; margin: 0px; }")

        def _make_tab_scroll(inner_widget):
            sc = QScrollArea()
            sc.setWidgetResizable(True)
            sc.setFrameShape(QScrollArea.NoFrame)
            sc.setWidget(inner_widget)
            return sc

        # TAB 1: ADD DATA
        tab_data = QWidget()
        g1 = QVBoxLayout(tab_data)
        g1.setSpacing(14); g1.setContentsMargins(12, 18, 12, 12)

        grp_source = create_groupbox("Load File")
        gv_source = QVBoxLayout(grp_source)
        gv_source.setSpacing(8); gv_source.setContentsMargins(12, 16, 12, 12)
        btn_lay = QHBoxLayout()
        self.btn_add_raster = QPushButton("+ Raster")
        self.btn_add_vector = QPushButton("+ Vector")
        for b in [self.btn_add_raster, self.btn_add_vector]: b.setObjectName("btnSecondary")
        btn_lay.addWidget(self.btn_add_raster)
        btn_lay.addWidget(self.btn_add_vector)
        gv_source.addLayout(btn_lay)
        self.btn_add_raster.clicked.connect(self._open_raster_file)
        self.btn_add_vector.clicked.connect(self._open_vector_file)
        g1.addWidget(grp_source)

        grp_bands = create_groupbox("Raster Band Selection")
        gv_bands = QVBoxLayout(grp_bands)
        gv_bands.setSpacing(8); gv_bands.setContentsMargins(12, 16, 12, 12)
        mode_lay = QHBoxLayout()
        self.rb_single = QRadioButton("Single Band")
        self.rb_rgb = QRadioButton("RGB")
        self.rb_single.setChecked(True)
        bg = QButtonGroup(self); bg.addButton(self.rb_single); bg.addButton(self.rb_rgb)
        self.rb_single.toggled.connect(self._toggle_band_mode)
        mode_lay.addWidget(self.rb_single); mode_lay.addWidget(self.rb_rgb); mode_lay.addStretch()
        gv_bands.addLayout(mode_lay)

        band_grid = QGridLayout()
        band_grid.setSpacing(6)
        self.lbl_band = QLabel("Band:"); self.sp_band = QSpinBox(); self.sp_band.setMinimum(1); self.sp_band.setMaximum(100)
        band_grid.addWidget(self.lbl_band, 0, 0); band_grid.addWidget(self.sp_band, 0, 1)
        self.lbl_r = QLabel("R:"); self.sp_r = QSpinBox(); self.sp_r.setRange(1, 100); self.sp_r.setValue(1)
        self.lbl_g = QLabel("G:"); self.sp_g = QSpinBox(); self.sp_g.setRange(1, 100); self.sp_g.setValue(2)
        self.lbl_b = QLabel("B:"); self.sp_b = QSpinBox(); self.sp_b.setRange(1, 100); self.sp_b.setValue(3)
        for w in [self.lbl_r, self.sp_r, self.lbl_g, self.sp_g, self.lbl_b, self.sp_b]: w.setVisible(False)
        band_grid.addWidget(self.lbl_r, 1, 0); band_grid.addWidget(self.sp_r, 1, 1)
        band_grid.addWidget(self.lbl_g, 1, 2); band_grid.addWidget(self.sp_g, 1, 3)
        band_grid.addWidget(self.lbl_b, 2, 0); band_grid.addWidget(self.sp_b, 2, 1)
        gv_bands.addLayout(band_grid)

        px_lay = QHBoxLayout()
        px_lay.addWidget(QLabel("Max pixels (k):"))
        self.sp_maxpx = QSpinBox(); self.sp_maxpx.setRange(50, 10000); self.sp_maxpx.setValue(1000)
        px_lay.addWidget(self.sp_maxpx); px_lay.addStretch()
        gv_bands.addLayout(px_lay)
        g1.addWidget(grp_bands)

        self.btn_read = QPushButton("READ DATA && RENDER")
        self.btn_read.setObjectName("btnPrimary")
        self.btn_read.setMinimumHeight(36)
        f_b = self.btn_read.font(); f_b.setBold(True); self.btn_read.setFont(f_b)
        self.btn_read.clicked.connect(self._read_and_render)
        g1.addWidget(self.btn_read)
        g1.addStretch()
        self.tab_right.addTab(_make_tab_scroll(tab_data), "Data")

        # TAB 2: LAYERS LIST
        tab_list = QWidget()
        g_list = QVBoxLayout(tab_list)
        g_list.setSpacing(10); g_list.setContentsMargins(12, 12, 12, 12)

        g_list.addWidget(QLabel("Drag to reorder (top = drawn on top):"))
        self.list_layers = QListWidget()
        self.list_layers.setDragDropMode(QAbstractItemView.InternalMove)
        self.list_layers.setMinimumHeight(220)
        self.list_layers.itemChanged.connect(self._trigger_live_update)
        self.list_layers.model().rowsMoved.connect(self._trigger_live_update)
        self.list_layers.currentItemChanged.connect(self._on_layer_changed)
        self.list_layers.setContextMenuPolicy(Qt.CustomContextMenu)
        self.list_layers.customContextMenuRequested.connect(self._show_layer_context_menu)
        g_list.addWidget(self.list_layers, stretch=1)

        self.btn_remove = QPushButton("Remove Selected")
        self.btn_remove.setObjectName("btnSecondary")
        self.btn_remove.clicked.connect(self._remove_layer)
        g_list.addWidget(self.btn_remove)

        # VECTOR SYMBOLOGY GROUPBOX
        self.grp_vecstyle = create_groupbox("Vector Symbology")
        gv = QVBoxLayout(self.grp_vecstyle)
        gv.setContentsMargins(12, 16, 12, 12)
        gv.setSpacing(10)

        gv.addWidget(QLabel("Symbology:"))
        self.cb_vec_symbology = QComboBox()
        self.cb_vec_symbology.addItems(["Single Symbol", "Categorized"])
        self.cb_vec_symbology.currentIndexChanged.connect(self._toggle_vec_symbology_mode)
        gv.addWidget(self.cb_vec_symbology)

        grp_fill = create_groupbox("Fill && Outline")
        gv_fill = QVBoxLayout(grp_fill)
        gv_fill.setContentsMargins(10, 14, 10, 10); gv_fill.setSpacing(6)
        fill_row = QHBoxLayout()
        self.chk_vec_fill = QCheckBox("Fill")
        self.chk_vec_fill.setChecked(True)
        self.chk_vec_fill.toggled.connect(self._apply_vector_style)
        fill_row.addWidget(self.chk_vec_fill)
        self.btn_vec_fillcolor = QPushButton()
        self.btn_vec_fillcolor.setFixedSize(26, 26)
        self.btn_vec_fillcolor.clicked.connect(self._pick_vec_fill_color)
        fill_row.addWidget(self.btn_vec_fillcolor)
        fill_row.addWidget(QLabel("Alpha:"))
        self.sp_vec_fillalpha = QDoubleSpinBox()
        self.sp_vec_fillalpha.setRange(0.0, 1.0)
        self.sp_vec_fillalpha.setSingleStep(0.05)
        self.sp_vec_fillalpha.setValue(0.55)
        self.sp_vec_fillalpha.valueChanged.connect(self._apply_vector_style)
        fill_row.addWidget(self.sp_vec_fillalpha)
        fill_row.addStretch()
        gv_fill.addLayout(fill_row)

        outline_row = QHBoxLayout()
        outline_row.addWidget(QLabel("Outline:"))
        self.btn_vec_outlinecolor = QPushButton()
        self.btn_vec_outlinecolor.setFixedSize(26, 26)
        self.btn_vec_outlinecolor.clicked.connect(self._pick_vec_outline_color)
        outline_row.addWidget(self.btn_vec_outlinecolor)
        outline_row.addWidget(QLabel("Width:"))
        self.sp_vec_outlinewidth = QDoubleSpinBox()
        self.sp_vec_outlinewidth.setRange(0.0, 10.0)
        self.sp_vec_outlinewidth.setSingleStep(0.25)
        self.sp_vec_outlinewidth.setValue(1.0)
        self.sp_vec_outlinewidth.valueChanged.connect(self._apply_vector_style)
        outline_row.addWidget(self.sp_vec_outlinewidth)
        outline_row.addStretch()
        gv_fill.addLayout(outline_row)
        gv.addWidget(grp_fill)

        self._set_color_button(self.btn_vec_fillcolor, "#3388ff")
        self._set_color_button(self.btn_vec_outlinecolor, "#1f1f1f")

        grp_cat = create_groupbox("Categorized Values")
        gv_cat = QVBoxLayout(grp_cat)
        gv_cat.setContentsMargins(10, 14, 10, 10); gv_cat.setSpacing(6)
        self.lbl_vec_field = QLabel("Category Field:")
        gv_cat.addWidget(self.lbl_vec_field)
        self.cb_vec_field = QComboBox()
        self.cb_vec_field.currentIndexChanged.connect(self._apply_vector_style)
        gv_cat.addWidget(self.cb_vec_field)
        self.btn_vec_classify = QPushButton("Classify Unique Values")
        self.btn_vec_classify.clicked.connect(self._classify_vector_field)
        gv_cat.addWidget(self.btn_vec_classify)

        self._vec_cat_scroll = QScrollArea()
        self._vec_cat_scroll.setWidgetResizable(True)
        self._vec_cat_scroll.setMinimumHeight(140)
        self._vec_cat_scroll.setFrameShape(QScrollArea.StyledPanel)
        self._vec_cat_container = QWidget()
        self._vec_cat_layout = QVBoxLayout(self._vec_cat_container)
        self._vec_cat_layout.setContentsMargins(4, 4, 4, 4)
        self._vec_cat_layout.setSpacing(4)
        self._vec_cat_layout.addStretch()
        self._vec_cat_scroll.setWidget(self._vec_cat_container)
        gv_cat.addWidget(self._vec_cat_scroll)
        gv.addWidget(grp_cat)

        self.grp_vecstyle.setVisible(False)
        g_list.addWidget(self.grp_vecstyle)
        g_list.addStretch()
        self.tab_right.addTab(_make_tab_scroll(tab_list), "Layers")

        # NOTE: there is no left panel any more — Data and Layers now live
        # as tabs on the right-hand panel above, so the space that used to
        # be taken up by the left panel is left entirely to the map canvas.

        # -------------------------------------------------------------
        # CENTER PANEL (MAP)
        # -------------------------------------------------------------
        center_panel = QWidget()
        center_lay = QVBoxLayout(center_panel)
        center_lay.setContentsMargins(4, 0, 4, 0)
        center_lay.setSpacing(8)

        tb_lay = QHBoxLayout()
        tb_lay.setContentsMargins(0, 0, 0, 0)
        tb_lay.setSpacing(6)
        self.btn_fit = QPushButton("Fit View")
        self.btn_fit.clicked.connect(self._fit_view_map)
        self.btn_zin = QPushButton("Zoom In")
        self.btn_zin.clicked.connect(self._zoom_in_map)
        self.btn_zout = QPushButton("Zoom Out")
        self.btn_zout.clicked.connect(self._zoom_out_map)
        self.btn_full = QPushButton("Full Extent")
        self.btn_full.clicked.connect(self._zoom_to_full_extent)

        for b in [self.btn_fit, self.btn_zin, self.btn_zout, self.btn_full]:
            fb = b.font(); fb.setBold(True); b.setFont(fb)
            b.setObjectName("btnSecondary")
            tb_lay.addWidget(b)
        tb_lay.addStretch()
        center_lay.addLayout(tb_lay)

        self.map_scroll = QScrollArea()
        self.map_scroll.setWidgetResizable(True)
        self.map_scroll.setFrameShape(QScrollArea.NoFrame)
        self.map_scroll.setAlignment(Qt.AlignCenter)

        self.fig_map = Figure()
        self.canvas_map = FigureCanvas(self.fig_map)
        self.map_scroll.setWidget(self.canvas_map)
        center_lay.addWidget(self.map_scroll, stretch=1)

        status_lay = QHBoxLayout()
        status_lay.setContentsMargins(0, 0, 0, 0)
        status_lay.setSpacing(8)
        self.lbl_status = QLabel("")
        self.lbl_status.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        status_lay.addWidget(self.lbl_status, stretch=1)
        self.progress_status = QProgressBar()
        self.progress_status.setFixedWidth(140)
        self.progress_status.setFixedHeight(14)
        self.progress_status.setTextVisible(False)
        self.progress_status.setRange(0, 0)
        self.progress_status.hide()
        status_lay.addWidget(self.progress_status)
        center_lay.addLayout(status_lay)
        self.main_splitter.addWidget(center_panel)
        self._set_status("Load layers in the Data tab (right panel), arrange order, then click 'READ DATA & RENDER'.", "info")

        # -------------------------------------------------------------
        # RIGHT PANEL (continued — Display / Title & Font / Geometry /
        # Colorbar tabs below; Data && Layers tabs were added earlier)
        # -------------------------------------------------------------

        # --- TAB DISPLAY ---
        tab_disp = QWidget()
        disp_v = QVBoxLayout(tab_disp)
        disp_v.setSpacing(10); disp_v.setContentsMargins(8, 12, 10, 12)

        grp_canvas_size = create_groupbox("Canvas Size")
        gcz = QGridLayout(grp_canvas_size); gcz.setSpacing(6); gcz.setContentsMargins(10, 14, 10, 10)
        gcz.setColumnStretch(0, 0); gcz.setColumnStretch(1, 1)

        gcz.addWidget(QLabel("Paper Size:"), 0, 0)
        self.cb_paper_size = QComboBox()
        self.cb_paper_size.addItems([
            "Fit to Window", "A0", "A1", "A2", "A3", "A4", "A5",
            "US Letter", "US Legal", "US Tabloid", "Custom",
        ])
        self.cb_paper_size.currentIndexChanged.connect(self._toggle_canvas_size_opts)
        gcz.addWidget(self.cb_paper_size, 0, 1)

        gcz.addWidget(QLabel("Orientation:"), 1, 0)
        self.cb_paper_orient = QComboBox()
        self.cb_paper_orient.addItems(["Landscape", "Portrait"])
        gcz.addWidget(self.cb_paper_orient, 1, 1)

        gcz.addWidget(QLabel("Custom W/H (cm):"), 2, 0)
        self.sp_custom_w_cm = QDoubleSpinBox(); self.sp_custom_w_cm.setRange(1, 500); self.sp_custom_w_cm.setValue(29.7)
        self.sp_custom_h_cm = QDoubleSpinBox(); self.sp_custom_h_cm.setRange(1, 500); self.sp_custom_h_cm.setValue(21.0)
        gcz.addLayout(_stacked_pair(self.sp_custom_w_cm, "W:", self.sp_custom_h_cm, "H:"), 2, 1)

        gcz.addWidget(QLabel("Export DPI:"), 3, 0)
        self.sp_canvas_dpi = QSpinBox(); self.sp_canvas_dpi.setRange(72, 1200); self.sp_canvas_dpi.setValue(300)
        gcz.addWidget(self.sp_canvas_dpi, 3, 1)

        self.btn_apply_canvas = QPushButton("Apply Canvas Size")
        self.btn_apply_canvas.setObjectName("btnSecondary")
        self.btn_apply_canvas.clicked.connect(self._apply_canvas_size)
        gcz.addWidget(self.btn_apply_canvas, 4, 0, 1, 2)

        self.lbl_canvas_size_info = QLabel("Fit to Window: canvas follows the app window size.")
        self.lbl_canvas_size_info.setWordWrap(True)
        f_hint = self.lbl_canvas_size_info.font(); f_hint.setItalic(True); f_hint.setPointSize(max(7, f_hint.pointSize() - 1))
        self.lbl_canvas_size_info.setFont(f_hint)
        gcz.addWidget(self.lbl_canvas_size_info, 5, 0, 1, 2)

        disp_v.addWidget(grp_canvas_size)

        grp_canvas = create_groupbox("Canvas")
        gg = QGridLayout(grp_canvas); gg.setSpacing(6); gg.setContentsMargins(10, 14, 10, 10)
        gg.setColumnStretch(0, 0); gg.setColumnStretch(1, 1)
        gg.addWidget(QLabel("Background:"), 0, 0)
        self.cb_bg_color = QComboBox()
        self.cb_bg_color.addItems(["White", "Soft Black", "Transparent (Dark Text)", "Transparent (Light Text)"])
        gg.addWidget(self.cb_bg_color, 0, 1)

        self.chk_legend = QCheckBox("Show Colorbar / Legend"); self.chk_legend.setChecked(True)
        gg.addWidget(self.chk_legend, 1, 0, 1, 2)
        self.chk_axes = QCheckBox("Show Coordinate Axes"); self.chk_axes.setChecked(True)
        gg.addWidget(self.chk_axes, 2, 0, 1, 2)
        self.chk_grid = QCheckBox("Show Grid Lines"); self.chk_grid.setChecked(True)
        gg.addWidget(self.chk_grid, 3, 0, 1, 2)

        gg.addWidget(QLabel("Raster Alpha:"), 4, 0)
        self.sp_raster_alpha = QDoubleSpinBox()
        self.sp_raster_alpha.setRange(0.0, 1.0); self.sp_raster_alpha.setSingleStep(0.1); self.sp_raster_alpha.setValue(1.0)
        self.sp_raster_alpha.valueChanged.connect(self._trigger_live_update)
        gg.addWidget(self.sp_raster_alpha, 4, 1)
        disp_v.addWidget(grp_canvas)

        grp_north = create_groupbox("North Arrow")
        gn = QGridLayout(grp_north); gn.setSpacing(6); gn.setContentsMargins(10, 14, 10, 10)
        gn.setColumnStretch(0, 0); gn.setColumnStretch(1, 1)
        self.chk_north_arrow = QCheckBox("Show North Arrow")
        gn.addWidget(self.chk_north_arrow, 0, 0, 1, 2)
        gn.addWidget(QLabel("Style:"), 1, 0)
        self.cb_north_style = QComboBox()
        self.cb_north_style.addItems(["Simple Arrow", "Fancy Arrow", "Compass Rose (N-S-E-W)", "Classic Triangle", "Sleek Needle"])
        self.cb_north_style.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.cb_north_style.view().setMinimumWidth(220)
        gn.addWidget(self.cb_north_style, 1, 1)

        gn.addWidget(QLabel("Position X/Y:"), 2, 0)
        self.sp_north_x = QDoubleSpinBox(); self.sp_north_x.setRange(0, 1); self.sp_north_x.setSingleStep(0.01); self.sp_north_x.setValue(0.93)
        self.sp_north_y = QDoubleSpinBox(); self.sp_north_y.setRange(0, 1); self.sp_north_y.setSingleStep(0.01); self.sp_north_y.setValue(0.90)
        gn.addLayout(_stacked_pair(self.sp_north_x, "X:", self.sp_north_y, "Y:"), 2, 1)

        gn.addWidget(QLabel("Size:"), 3, 0)
        north_sz_lay = QHBoxLayout()
        self.sp_north_size = QDoubleSpinBox(); self.sp_north_size.setRange(0.02, 0.5); self.sp_north_size.setSingleStep(0.01); self.sp_north_size.setValue(0.08)
        north_sz_lay.addWidget(self.sp_north_size); north_sz_lay.addStretch()
        gn.addLayout(north_sz_lay, 3, 1)
        disp_v.addWidget(grp_north)

        grp_scale = create_groupbox("Scale Bar")
        gs = QGridLayout(grp_scale); gs.setSpacing(6); gs.setContentsMargins(10, 14, 10, 10)
        gs.setColumnStretch(0, 0); gs.setColumnStretch(1, 1)
        self.chk_scalebar = QCheckBox("Show Scale Bar")
        gs.addWidget(self.chk_scalebar, 0, 0, 1, 2)
        gs.addWidget(QLabel("Style:"), 1, 0)
        self.cb_scalebar_style = QComboBox()
        self.cb_scalebar_style.addItems(["Simple Line", "Stepped Line", "Single Box", "Double Box"])
        gs.addWidget(self.cb_scalebar_style, 1, 1)

        gs.addWidget(QLabel("Orientation:"), 2, 0)
        self.cb_scalebar_orient = QComboBox()
        self.cb_scalebar_orient.addItems(["Horizontal", "Vertical"])
        gs.addWidget(self.cb_scalebar_orient, 2, 1)

        gs.addWidget(QLabel("Position X/Y:"), 3, 0)
        self.sp_scalebar_x = QDoubleSpinBox(); self.sp_scalebar_x.setRange(0, 1); self.sp_scalebar_x.setSingleStep(0.01); self.sp_scalebar_x.setValue(0.05)
        self.sp_scalebar_y = QDoubleSpinBox(); self.sp_scalebar_y.setRange(0, 1); self.sp_scalebar_y.setSingleStep(0.01); self.sp_scalebar_y.setValue(0.05)
        gs.addLayout(_stacked_pair(self.sp_scalebar_x, "X:", self.sp_scalebar_y, "Y:"), 3, 1)

        gs.addWidget(QLabel("Length/Unit:"), 4, 0)
        self.sp_scalebar_length = QDoubleSpinBox(); self.sp_scalebar_length.setRange(0.001, 1000000); self.sp_scalebar_length.setDecimals(3); self.sp_scalebar_length.setValue(1.0)
        self.cb_scalebar_unit = QComboBox(); self.cb_scalebar_unit.addItems(["Auto", "m", "km"])
        gs.addLayout(_stacked_pair(self.sp_scalebar_length, "L:", self.cb_scalebar_unit, "U:"), 4, 1)

        gs.addWidget(QLabel("Segments:"), 5, 0)
        scale_seg_lay = QHBoxLayout()
        self.sp_scalebar_segments = QSpinBox(); self.sp_scalebar_segments.setRange(2, 12); self.sp_scalebar_segments.setValue(4)
        scale_seg_lay.addWidget(self.sp_scalebar_segments); scale_seg_lay.addStretch()
        gs.addLayout(scale_seg_lay, 5, 1)
        disp_v.addWidget(grp_scale)
        disp_v.addStretch(1)

        self.tab_right.addTab(_make_tab_scroll(tab_disp), "Display")

        # --- TAB BASEMAP ---
        tab_basemap = QWidget()
        basemap_v = QVBoxLayout(tab_basemap)
        basemap_v.setSpacing(10); basemap_v.setContentsMargins(8, 12, 10, 12)

        grp_basemap = create_groupbox("Basemap")
        gb = QGridLayout(grp_basemap); gb.setSpacing(6); gb.setContentsMargins(10, 14, 10, 10)
        gb.setColumnStretch(0, 0); gb.setColumnStretch(1, 1)
        gb.addWidget(QLabel("Provider:"), 0, 0)
        self.cb_basemap = QComboBox()
        # Zero third-party dependency: every entry is a plain dict with a
        # {z}/{x}/{y} (or {z}/{y}/{x} — QGIS's XYZ connection just does
        # placeholder substitution, order in the path doesn't matter) tile
        # URL template, its required attribution text, and the provider's
        # max zoom. These are the same public, no-API-key XYZ endpoints
        # used by xyzservices/leaflet-providers (the database behind
        # contextily) and by QuickMapServices.
        self.basemap_dict = {
            "None": None,
            "Esri: Satellite": {
                "url": "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
                "attribution": "Tiles (C) Esri -- Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community",
                "zmax": 19,
            },
            "Esri: Topo": {
                "url": "https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}",
                "attribution": "Tiles (C) Esri -- Esri, DeLorme, NAVTEQ, TomTom, Intermap, iPC, USGS, FAO, NPS, NRCAN, GeoBase, Kadaster NL, Ordnance Survey, Esri Japan, METI, Esri China (Hong Kong), and the GIS User Community",
                "zmax": 19,
            },
            "Esri: Terrain": {
                "url": "https://server.arcgisonline.com/ArcGIS/rest/services/World_Terrain_Base/MapServer/tile/{z}/{y}/{x}",
                "attribution": "Tiles (C) Esri -- Source: USGS, Esri, TANA, DeLorme, and NPS",
                "zmax": 13,
            },
            "Esri: StreetMap": {
                "url": "https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}",
                "attribution": "Tiles (C) Esri -- Source: Esri, DeLorme, NAVTEQ, USGS, Intermap, iPC, NRCAN, Esri Japan, METI, Esri China (Hong Kong), Esri (Thailand), TomTom, 2012",
                "zmax": 19,
            },
            "Esri: Shaded Relief": {
                "url": "https://server.arcgisonline.com/ArcGIS/rest/services/World_Shaded_Relief/MapServer/tile/{z}/{y}/{x}",
                "attribution": "Tiles (C) Esri -- Source: Esri",
                "zmax": 13,
            },
            "Esri: Physical": {
                "url": "https://server.arcgisonline.com/ArcGIS/rest/services/World_Physical_Map/MapServer/tile/{z}/{y}/{x}",
                "attribution": "Tiles (C) Esri -- Source: US National Park Service",
                "zmax": 8,
            },
            "Esri: Ocean": {
                "url": "https://server.arcgisonline.com/ArcGIS/rest/services/Ocean/World_Ocean_Base/MapServer/tile/{z}/{y}/{x}",
                "attribution": "Tiles (C) Esri -- Sources: GEBCO, NOAA, CHS, OSU, UNH, CSUMB, National Geographic, DeLorme, NAVTEQ, and Esri",
                "zmax": 13,
            },
            "Esri: NatGeo": {
                "url": "https://server.arcgisonline.com/ArcGIS/rest/services/NatGeo_World_Map/MapServer/tile/{z}/{y}/{x}",
                "attribution": "Tiles (C) Esri -- National Geographic, Esri, DeLorme, NAVTEQ, UNEP-WCMC, USGS, NASA, ESA, METI, NRCAN, GEBCO, NOAA, iPC",
                "zmax": 16,
            },
            "Esri: Gray Canvas": {
                "url": "https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Base/MapServer/tile/{z}/{y}/{x}",
                "attribution": "Tiles (C) Esri -- Esri, DeLorme, NAVTEQ",
                "zmax": 16,
            },
            "OSM: Mapnik": {
                "url": "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
                "attribution": "(C) OpenStreetMap contributors",
                "zmax": 19,
            },
            "OSM: Humanitarian (HOT)": {
                "url": "https://a.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png",
                "attribution": "(C) OpenStreetMap contributors, Tiles style by Humanitarian OpenStreetMap Team hosted by OpenStreetMap France",
                "zmax": 19,
            },
            "OSM: CyclOSM": {
                "url": "https://a.tile-cyclosm.openstreetmap.fr/cyclosm/{z}/{x}/{y}.png",
                "attribution": "CyclOSM | Map data: (C) OpenStreetMap contributors",
                "zmax": 20,
            },
            "CartoDB: Positron": {
                "url": "https://a.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png",
                "attribution": "(C) OpenStreetMap contributors (C) CARTO",
                "zmax": 20,
            },
            "CartoDB: Positron (No Labels)": {
                "url": "https://a.basemaps.cartocdn.com/light_nolabels/{z}/{x}/{y}.png",
                "attribution": "(C) OpenStreetMap contributors (C) CARTO",
                "zmax": 20,
            },
            "CartoDB: Dark Matter": {
                "url": "https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png",
                "attribution": "(C) OpenStreetMap contributors (C) CARTO",
                "zmax": 20,
            },
            "CartoDB: Dark Matter (No Labels)": {
                "url": "https://a.basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}.png",
                "attribution": "(C) OpenStreetMap contributors (C) CARTO",
                "zmax": 20,
            },
            "CartoDB: Voyager": {
                "url": "https://a.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png",
                "attribution": "(C) OpenStreetMap contributors (C) CARTO",
                "zmax": 20,
            },
            "CartoDB: Voyager (No Labels)": {
                "url": "https://a.basemaps.cartocdn.com/rastertiles/voyager_nolabels/{z}/{x}/{y}.png",
                "attribution": "(C) OpenStreetMap contributors (C) CARTO",
                "zmax": 20,
            },
            "OpenTopoMap": {
                "url": "https://a.tile.opentopomap.org/{z}/{x}/{y}.png",
                "attribution": "Map data: (C) OpenStreetMap contributors, SRTM | Map style: (C) OpenTopoMap (CC-BY-SA)",
                "zmax": 17,
            },
            "HikeBike: Base": {
                "url": "https://tiles.wmflabs.org/hikebike/{z}/{x}/{y}.png",
                "attribution": "(C) OpenStreetMap contributors",
                "zmax": 19,
            },
            "HikeBike: Hillshade": {
                "url": "https://tiles.wmflabs.org/hillshading/{z}/{x}/{y}.png",
                "attribution": "(C) OpenStreetMap contributors",
                "zmax": 15,
            },
            "OpenSeaMap (Overlay)": {
                "url": "https://tiles.openseamap.org/seamark/{z}/{x}/{y}.png",
                "attribution": "Map data: (C) OpenSeaMap contributors",
                "zmax": 18,
            },
            "NASA: Blue Marble": {
                "url": "https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/BlueMarble_NextGeneration/default/GoogleMapsCompatible_Level8/{z}/{y}/{x}.jpeg",
                "attribution": "Imagery provided by services from the Global Imagery Browse Services (GIBS), operated by the NASA/GSFC/Earth Science Data and Information System (ESDIS) with funding provided by NASA/HQ.",
                "zmax": 8,
            },
            "NASA: VIIRS Earth at Night": {
                "url": "https://map1.vis.earthdata.nasa.gov/wmts-webmerc/VIIRS_CityLights_2012/default/GoogleMapsCompatible_Level8/{z}/{y}/{x}.jpg",
                "attribution": "Imagery provided by services from the Global Imagery Browse Services (GIBS), operated by the NASA/GSFC/Earth Science Data and Information System (ESDIS) with funding provided by NASA/HQ.",
                "zmax": 8,
            },
            "NASA: MODIS True Color": {
                "url": "https://map1.vis.earthdata.nasa.gov/wmts-webmerc/MODIS_Terra_CorrectedReflectance_TrueColor/default/GoogleMapsCompatible_Level9/{z}/{y}/{x}.jpg",
                "attribution": "Imagery provided by services from the Global Imagery Browse Services (GIBS), operated by the NASA/GSFC/Earth Science Data and Information System (ESDIS) with funding provided by NASA/HQ.",
                "zmax": 9,
            },
            "NASA: ASTER Shaded Relief": {
                "url": "https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/ASTER_GDEM_Greyscale_Shaded_Relief/default/GoogleMapsCompatible_Level12/{z}/{y}/{x}.jpg",
                "attribution": "Imagery provided by services from the Global Imagery Browse Services (GIBS), operated by the NASA/GSFC/Earth Science Data and Information System (ESDIS) with funding provided by NASA/HQ.",
                "zmax": 12,
            },
            "Esri: Antarctic Imagery": {
                "url": "https://server.arcgisonline.com/ArcGIS/rest/services/Polar/Antarctic_Imagery/MapServer/tile/{z}/{y}/{x}",
                "attribution": "Earthstar Geographics",
                "zmax": 13,
            },
            "Esri: Arctic Imagery": {
                "url": "https://server.arcgisonline.com/ArcGIS/rest/services/Polar/Arctic_Imagery/MapServer/tile/{z}/{y}/{x}",
                "attribution": "Earthstar Geographics",
                "zmax": 13,
            },
            "BaseMapDE: Color (Germany)": {
                "url": "https://sgx.geodatenzentrum.de/wmts_basemapde/tile/1.0.0/de_basemapde_web_raster_farbe/default/GLOBAL_WEBMERCATOR/{z}/{y}/{x}.png",
                "attribution": "Map data: (C) dl-de/by-2-0",
                "zmax": 19,
            },
            "BaseMapDE: Grey (Germany)": {
                "url": "https://sgx.geodatenzentrum.de/wmts_basemapde/tile/1.0.0/de_basemapde_web_raster_grau/default/GLOBAL_WEBMERCATOR/{z}/{y}/{x}.png",
                "attribution": "Map data: (C) dl-de/by-2-0",
                "zmax": 19,
            },
            "TopPlusOpen: Color (Germany)": {
                "url": "https://sgx.geodatenzentrum.de/wmts_topplus_open/tile/1.0.0/web/default/WEBMERCATOR/{z}/{y}/{x}.png",
                "attribution": "Map data: (C) dl-de/by-2-0",
                "zmax": 18,
            },
            "TopPlusOpen: Grey (Germany)": {
                "url": "https://sgx.geodatenzentrum.de/wmts_topplus_open/tile/1.0.0/web_grau/default/WEBMERCATOR/{z}/{y}/{x}.png",
                "attribution": "Map data: (C) dl-de/by-2-0",
                "zmax": 18,
            },
            "SwissFederalGeoportal: SWISSIMAGE (Switzerland)": {
                "url": "https://wmts.geo.admin.ch/1.0.0/ch.swisstopo.swissimage/default/current/3857/{z}/{x}/{y}.jpeg",
                "attribution": "(C) swisstopo",
                "zmax": 19,
            },
            "SwissFederalGeoportal: National Map Color (Switzerland)": {
                "url": "https://wmts.geo.admin.ch/1.0.0/ch.swisstopo.pixelkarte-farbe/default/current/3857/{z}/{x}/{y}.jpeg",
                "attribution": "(C) swisstopo",
                "zmax": 18,
            },
            "SwissFederalGeoportal: National Map Grey (Switzerland)": {
                "url": "https://wmts.geo.admin.ch/1.0.0/ch.swisstopo.pixelkarte-grau/default/current/3857/{z}/{x}/{y}.jpeg",
                "attribution": "(C) swisstopo",
                "zmax": 18,
            },
            "nlmaps: Standaard (Netherlands)": {
                "url": "https://service.pdok.nl/brt/achtergrondkaart/wmts/v2_0/standaard/EPSG:3857/{z}/{x}/{y}.png",
                "attribution": "Kaartgegevens (C) Kadaster",
                "zmax": 19,
            },
            "nlmaps: Luchtfoto / Aerial (Netherlands)": {
                "url": "https://service.pdok.nl/hwh/luchtfotorgb/wmts/v1_0/Actueel_ortho25/EPSG:3857/{z}/{x}/{y}.jpeg",
                "attribution": "Kaartgegevens (C) Kadaster",
                "zmax": 19,
            },
            "USGS: US Imagery (USA)": {
                "url": "https://basemap.nationalmap.gov/arcgis/rest/services/USGSImageryOnly/MapServer/tile/{z}/{y}/{x}",
                "attribution": "Tiles courtesy of the U.S. Geological Survey",
                "zmax": 19,
            },
            "USGS: US Topo (USA)": {
                "url": "https://basemap.nationalmap.gov/arcgis/rest/services/USGSTopo/MapServer/tile/{z}/{y}/{x}",
                "attribution": "Tiles courtesy of the U.S. Geological Survey",
                "zmax": 19,
            },
            "FreeMapSK (Slovakia)": {
                "url": "https://a.freemap.sk/T/{z}/{x}/{y}.jpeg",
                "attribution": "(C) OpenStreetMap contributors, visualization CC-BY-SA 2.0 Freemap.sk",
                "zmax": 16,
            },
            "MtbMap (Mountain Bike)": {
                "url": "https://tile.mtbmap.cz/mtbmap_tiles/{z}/{x}/{y}.png",
                "attribution": "(C) OpenStreetMap contributors & USGS",
                "zmax": 18,
            },
            "OPNVKarte (Public Transport)": {
                "url": "https://tileserver.memomaps.de/tilegen/{z}/{x}/{y}.png",
                "attribution": "Map memomaps.de CC-BY-SA, map data (C) OpenStreetMap contributors",
                "zmax": 18,
            },
            "OpenRailwayMap": {
                "url": "https://a.tiles.openrailwaymap.org/standard/{z}/{x}/{y}.png",
                "attribution": "Map data: (C) OpenStreetMap contributors | Map style: (C) OpenRailwayMap (CC-BY-SA)",
                "zmax": 19,
            },
            "OpenSnowMap: Pistes": {
                "url": "https://tiles.opensnowmap.org/pistes/{z}/{x}/{y}.png",
                "attribution": "Map data: (C) OpenStreetMap contributors & ODbL, style: (C) OpenSnowMap",
                "zmax": 18,
            },
            "SafeCast (Radiation)": {
                "url": "https://s3.amazonaws.com/te512.safecast.org/{z}/{x}/{y}.png",
                "attribution": "Map data: (C) OpenStreetMap contributors | Map style: (C) SafeCast (CC-BY-SA)",
                "zmax": 16,
            },
            "WaymarkedTrails: Hiking": {
                "url": "https://tile.waymarkedtrails.org/hiking/{z}/{x}/{y}.png",
                "attribution": "Map data: (C) OpenStreetMap contributors | Map style: (C) waymarkedtrails.org (CC-BY-SA)",
                "zmax": 18,
            },
            "WaymarkedTrails: Cycling": {
                "url": "https://tile.waymarkedtrails.org/cycling/{z}/{x}/{y}.png",
                "attribution": "Map data: (C) OpenStreetMap contributors | Map style: (C) waymarkedtrails.org (CC-BY-SA)",
                "zmax": 18,
            },
            "WaymarkedTrails: MTB": {
                "url": "https://tile.waymarkedtrails.org/mtb/{z}/{x}/{y}.png",
                "attribution": "Map data: (C) OpenStreetMap contributors | Map style: (C) waymarkedtrails.org (CC-BY-SA)",
                "zmax": 18,
            },
            "OpenAIP (Aviation, CC-BY-NC-SA - non-commercial only)": {
                "url": "https://1.tile.maps.openaip.net/geowebcache/service/tms/1.0.0/openaip_basemap@EPSG%3A900913@png/{z}/{x}/{y}.png",
                "attribution": "openAIP Data (CC-BY-NC-SA) -- non-commercial use only",
                "zmax": 14,
            },
            "UN: Clear Map Topo": {
                "url": "https://geoservices.un.org/arcgis/rest/services/WEBTOPO/MapServer/tile/{z}/{y}/{x}",
                "attribution": "Produced by United Nations Geospatial",
                "zmax": 6,
            },
        }
        self.cb_basemap.addItems(list(self.basemap_dict.keys()))
        self.cb_basemap.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.cb_basemap.view().setMinimumWidth(360)
        self.cb_basemap.currentIndexChanged.connect(self._trigger_live_update)
        gb.addWidget(self.cb_basemap, 0, 1)

        gb.addWidget(QLabel("Credit:"), 1, 0)
        cred_lay = QHBoxLayout()
        self.chk_show_attrib = QCheckBox("Show Credit"); self.chk_show_attrib.setChecked(True)
        self.chk_show_attrib.toggled.connect(self._trigger_live_update)
        cred_lay.addWidget(self.chk_show_attrib)
        cred_lay.addWidget(QLabel("Size:"))
        self.sp_attrib_size = QSpinBox(); self.sp_attrib_size.setRange(0, 20); self.sp_attrib_size.setValue(6)
        self.sp_attrib_size.valueChanged.connect(self._trigger_live_update)
        cred_lay.addWidget(self.sp_attrib_size); cred_lay.addStretch()
        gb.addLayout(cred_lay, 1, 1)
        basemap_v.addWidget(grp_basemap)
        basemap_v.addStretch(1)

        self.tab_right.addTab(_make_tab_scroll(tab_basemap), "Basemap")

        # --- TAB TITLE & FONT ---
        tab_font = QWidget()
        font_v = QVBoxLayout(tab_font)
        font_v.setSpacing(10); font_v.setContentsMargins(8, 12, 10, 12)

        grp_font = create_groupbox("Font")
        gfont = QGridLayout(grp_font); gfont.setSpacing(6); gfont.setContentsMargins(10, 14, 10, 10)
        gfont.setColumnStretch(0, 0); gfont.setColumnStretch(1, 1)
        gfont.addWidget(QLabel("Family:"), 0, 0)
        self.cb_font_family = QComboBox()
        self.cb_font_family.addItems(QFontDatabase().families())
        self.cb_font_family.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.cb_font_family.view().setMinimumWidth(280)
        for pref in ["Poppins", "Segoe UI", "Ubuntu"]:
            if pref in QFontDatabase().families():
                self.cb_font_family.setCurrentText(pref)
                break
        gfont.addWidget(self.cb_font_family, 0, 1)
        font_v.addWidget(grp_font)

        grp_title = create_groupbox("Map Title")
        gt = QGridLayout(grp_title); gt.setSpacing(6); gt.setContentsMargins(10, 14, 10, 10)
        gt.setColumnStretch(0, 0); gt.setColumnStretch(1, 1)
        gt.addWidget(QLabel("Text:"), 0, 0)
        self.le_title = QLineEdit("")
        gt.addWidget(self.le_title, 0, 1)
        gt.addWidget(QLabel("Style:"), 1, 0)
        title_style_lay = QHBoxLayout()
        self.chk_title_bold = QCheckBox("Bold"); self.chk_title_bold.setChecked(True)
        self.chk_title_italic = QCheckBox("Italic")
        title_style_lay.addWidget(self.chk_title_bold); title_style_lay.addWidget(self.chk_title_italic); title_style_lay.addStretch()
        gt.addLayout(title_style_lay, 1, 1)
        gt.addWidget(QLabel("Size:"), 2, 0)
        self.sp_title_size = QSpinBox(); self.sp_title_size.setRange(6, 40); self.sp_title_size.setValue(14)
        gt.addWidget(self.sp_title_size, 2, 1)
        gt.addWidget(QLabel("Alignment:"), 3, 0)
        self.cb_title_align = QComboBox()
        self.cb_title_align.addItems(["center", "left", "right"])
        gt.addWidget(self.cb_title_align, 3, 1)
        font_v.addWidget(grp_title)

        grp_sub = create_groupbox("Subtitle")
        gsub = QGridLayout(grp_sub); gsub.setSpacing(6); gsub.setContentsMargins(10, 14, 10, 10)
        gsub.setColumnStretch(0, 0); gsub.setColumnStretch(1, 1)
        gsub.addWidget(QLabel("Text:"), 0, 0)
        self.le_subtitle = QLineEdit("")
        gsub.addWidget(self.le_subtitle, 0, 1)
        gsub.addWidget(QLabel("Style:"), 1, 0)
        sub_style_lay = QHBoxLayout()
        self.chk_subtitle_bold = QCheckBox("Bold")
        self.chk_subtitle_italic = QCheckBox("Italic")
        sub_style_lay.addWidget(self.chk_subtitle_bold); sub_style_lay.addWidget(self.chk_subtitle_italic); sub_style_lay.addStretch()
        gsub.addLayout(sub_style_lay, 1, 1)
        gsub.addWidget(QLabel("Size:"), 2, 0)
        self.sp_sub_size = QSpinBox(); self.sp_sub_size.setRange(6, 40); self.sp_sub_size.setValue(11)
        gsub.addWidget(self.sp_sub_size, 2, 1)
        font_v.addWidget(grp_sub)

        grp_axislbl = create_groupbox("Axis Label Style")
        gax = QGridLayout(grp_axislbl); gax.setSpacing(6); gax.setContentsMargins(10, 14, 10, 10)
        gax.setColumnStretch(0, 0); gax.setColumnStretch(1, 1)
        gax.addWidget(QLabel("Style:"), 0, 0)
        axislbl_style_lay = QHBoxLayout()
        self.chk_axislbl_bold = QCheckBox("Bold")
        self.chk_axislbl_italic = QCheckBox("Italic")
        axislbl_style_lay.addWidget(self.chk_axislbl_bold); axislbl_style_lay.addWidget(self.chk_axislbl_italic); axislbl_style_lay.addStretch()
        gax.addLayout(axislbl_style_lay, 0, 1)
        font_v.addWidget(grp_axislbl)
        font_v.addStretch(1)

        self.tab_right.addTab(_make_tab_scroll(tab_font), "Title && Font")

        # --- TAB GEOMETRY ---
        tab_coords = QWidget()
        geo_v = QVBoxLayout(tab_coords)
        geo_v.setSpacing(10); geo_v.setContentsMargins(8, 12, 10, 12)

        grp_frame = create_groupbox("Map Frame")
        gmf = QGridLayout(grp_frame); gmf.setSpacing(6); gmf.setContentsMargins(10, 14, 10, 10)
        gmf.setColumnStretch(0, 0); gmf.setColumnStretch(1, 1)
        gmf.addWidget(QLabel("Position X/Y:"), 0, 0)
        self.sp_map_x = QDoubleSpinBox(); self.sp_map_x.setRange(0, 1); self.sp_map_x.setSingleStep(0.01); self.sp_map_x.setValue(0.08)
        self.sp_map_y = QDoubleSpinBox(); self.sp_map_y.setRange(0, 1); self.sp_map_y.setSingleStep(0.01); self.sp_map_y.setValue(0.12)
        gmf.addLayout(_stacked_pair(self.sp_map_x, "X:", self.sp_map_y, "Y:"), 0, 1)

        gmf.addWidget(QLabel("Width/Height:"), 1, 0)
        self.sp_map_w = QDoubleSpinBox(); self.sp_map_w.setRange(0.05, 1); self.sp_map_w.setSingleStep(0.01); self.sp_map_w.setValue(0.85)
        self.sp_map_h = QDoubleSpinBox(); self.sp_map_h.setRange(0.05, 1); self.sp_map_h.setSingleStep(0.01); self.sp_map_h.setValue(0.80)
        gmf.addLayout(_stacked_pair(self.sp_map_w, "W:", self.sp_map_h, "H:"), 1, 1)
        geo_v.addWidget(grp_frame)

        grp_ticks = create_groupbox("Coordinate Ticks && Grid")
        gmc = QGridLayout(grp_ticks); gmc.setSpacing(6); gmc.setContentsMargins(10, 14, 10, 10)
        gmc.setColumnStretch(0, 0); gmc.setColumnStretch(1, 1)
        gmc.addWidget(QLabel("Format:"), 0, 0)
        self.cb_coord_format = QComboBox()
        self.cb_coord_format.addItems(["DMS (Degree Minute Second)", "DM (Degree Minute)", "D (Decimal Degree)", "Default (UTM / Metre)"])
        self.cb_coord_format.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
        self.cb_coord_format.view().setMinimumWidth(260)
        gmc.addWidget(self.cb_coord_format, 0, 1)

        gmc.addWidget(QLabel("Coord Size/Dec:"), 1, 0)
        self.sp_coord_size = QSpinBox(); self.sp_coord_size.setRange(4, 30); self.sp_coord_size.setValue(9)
        self.sp_coord_decimals = QSpinBox(); self.sp_coord_decimals.setRange(0, 8); self.sp_coord_decimals.setValue(4)
        gmc.addLayout(_stacked_pair(self.sp_coord_size, "Sz:", self.sp_coord_decimals, "Dc:"), 1, 1)

        gmc.addWidget(QLabel("X/Y Label Rotation:"), 2, 0)
        self.sp_xlabel_rotation = QSpinBox(); self.sp_xlabel_rotation.setRange(0, 360); self.sp_xlabel_rotation.setValue(0); self.sp_xlabel_rotation.setSuffix("°")
        self.sp_ylabel_rotation = QSpinBox(); self.sp_ylabel_rotation.setRange(0, 360); self.sp_ylabel_rotation.setValue(90); self.sp_ylabel_rotation.setSuffix("°")
        gmc.addLayout(_stacked_pair(self.sp_xlabel_rotation, "X:", self.sp_ylabel_rotation, "Y:"), 2, 1)

        gmc.addWidget(QLabel("X/Y Tick Count:"), 3, 0)
        self.sp_xtick_count = QSpinBox(); self.sp_xtick_count.setRange(2, 20); self.sp_xtick_count.setValue(5)
        self.sp_ytick_count = QSpinBox(); self.sp_ytick_count.setRange(2, 20); self.sp_ytick_count.setValue(5)
        gmc.addLayout(_stacked_pair(self.sp_xtick_count, "X:", self.sp_ytick_count, "Y:"), 3, 1)

        gmc.addWidget(QLabel("Grid Style:"), 4, 0)
        self.cb_grid_style = QComboBox()
        self.cb_grid_style.addItems(["Solid (-)", "Dashed (--)", "Dotted (:)"])
        self.cb_grid_style.setCurrentText("Dashed (--)")
        gmc.addWidget(self.cb_grid_style, 4, 1)
        geo_v.addWidget(grp_ticks)

        grp_axistitle = create_groupbox("Axis Titles")
        gat = QGridLayout(grp_axistitle); gat.setSpacing(6); gat.setContentsMargins(10, 14, 10, 10)
        gat.setColumnStretch(0, 0); gat.setColumnStretch(1, 1)
        gat.addWidget(QLabel("X Axis Label:"), 0, 0)
        self.le_xaxis_label = QLineEdit(""); self.le_xaxis_label.setPlaceholderText("e.g. Longitude")
        gat.addWidget(self.le_xaxis_label, 0, 1)
        gat.addWidget(QLabel("Y Axis Label:"), 1, 0)
        self.le_yaxis_label = QLineEdit(""); self.le_yaxis_label.setPlaceholderText("e.g. Latitude")
        gat.addWidget(self.le_yaxis_label, 1, 1)
        geo_v.addWidget(grp_axistitle)
        geo_v.addStretch(1)

        self.tab_right.addTab(_make_tab_scroll(tab_coords), "Geometry")

        # --- TAB COLORBAR ---
        tab_cbar = QWidget()
        cbar_vbox = QVBoxLayout(tab_cbar)
        cbar_vbox.setContentsMargins(4, 8, 4, 8)
        cbar_vbox.setSpacing(10)

        self.tab_color_mode = QTabWidget()
        self.tab_color_mode.setTabPosition(QTabWidget.North)
        self.tab_color_mode.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)

        # Sub-Tab Continuous
        tab_cont = QWidget()
        cont_v = QVBoxLayout(tab_cont)
        cont_v.setSpacing(10); cont_v.setContentsMargins(8, 12, 10, 12)

        grp_stretch = create_groupbox("Stretch")
        g2 = QGridLayout(grp_stretch)
        g2.setColumnStretch(0, 0); g2.setColumnStretch(1, 1)
        g2.setSpacing(6); g2.setContentsMargins(10, 14, 10, 10)
        g2.addWidget(QLabel("Mode:"), 0, 0)
        self.cb_stretch = QComboBox()
        self.cb_stretch.addItems(["Actual Min-Max", "Percentile", "Manual Min-Max"])
        self.cb_stretch.currentIndexChanged.connect(self._toggle_stretch_opts)
        g2.addWidget(self.cb_stretch, 0, 1)

        self.lbl_pmin = QLabel("Pmin (%):"); self.sp_pmin = QDoubleSpinBox(); self.sp_pmin.setRange(0, 49); self.sp_pmin.setValue(2); self.sp_pmin.setSingleStep(0.5)
        g2.addWidget(self.lbl_pmin, 1, 0); g2.addWidget(self.sp_pmin, 1, 1)
        self.lbl_pmax = QLabel("Pmax (%):"); self.sp_pmax = QDoubleSpinBox(); self.sp_pmax.setRange(51, 100); self.sp_pmax.setValue(98); self.sp_pmax.setSingleStep(0.5)
        g2.addWidget(self.lbl_pmax, 2, 0); g2.addWidget(self.sp_pmax, 2, 1)
        self.lbl_vmin = QLabel("vmin:"); self.le_vmin = QLineEdit("0")
        g2.addWidget(self.lbl_vmin, 3, 0); g2.addWidget(self.le_vmin, 3, 1)
        self.lbl_vmax = QLabel("vmax:"); self.le_vmax = QLineEdit("1")
        g2.addWidget(self.lbl_vmax, 4, 0); g2.addWidget(self.le_vmax, 4, 1)
        cont_v.addWidget(grp_stretch)

        grp_cmap = create_groupbox("Colormap")
        g2b = QGridLayout(grp_cmap)
        g2b.setColumnStretch(0, 0); g2b.setColumnStretch(1, 1)
        g2b.setSpacing(6); g2b.setContentsMargins(10, 14, 10, 10)
        cmap_vbox = QVBoxLayout()
        cmap_vbox.setSpacing(4)
        self.lbl_cmap_name = QLabel("Nama Colormap")
        self.lbl_cmap_name.setAlignment(Qt.AlignCenter)
        self.lbl_cmap_name.setStyleSheet("font-weight: bold; font-size: 11px;")
        cmap_vbox.addWidget(self.lbl_cmap_name)

        cmap_lay = QHBoxLayout()
        cmap_lay.setContentsMargins(0, 0, 0, 0); cmap_lay.setSpacing(6)
        self.btn_cmap_prev = QPushButton("<"); self.btn_cmap_prev.setFixedSize(28, 28); self.btn_cmap_prev.setCursor(Qt.PointingHandCursor); self.btn_cmap_prev.clicked.connect(self._cmap_prev)
        self.lbl_cmap_preview = QLabel(); self.lbl_cmap_preview.setFixedHeight(28); self.lbl_cmap_preview.setScaledContents(True); self.lbl_cmap_preview.setStyleSheet("border: 1px solid #4a4a4a; border-radius: 4px;")
        self.btn_cmap_next = QPushButton(">"); self.btn_cmap_next.setFixedSize(28, 28); self.btn_cmap_next.setCursor(Qt.PointingHandCursor); self.btn_cmap_next.clicked.connect(self._cmap_next)

        cmap_lay.addWidget(self.btn_cmap_prev); cmap_lay.addWidget(self.lbl_cmap_preview, stretch=1); cmap_lay.addWidget(self.btn_cmap_next)
        cmap_vbox.addLayout(cmap_lay)
        g2b.addLayout(cmap_vbox, 0, 0, 1, 2)

        self.cmap_idx = COLORMAPS.index("NDVI_Custom") if "NDVI_Custom" in COLORMAPS else 0
        self.chk_reverse_cmap = QCheckBox("Reverse"); self.chk_reverse_cmap.toggled.connect(self._on_reverse_toggled)
        g2b.addWidget(self.chk_reverse_cmap, 1, 0)
        self.chk_nodata_transp = QCheckBox("Transparent Nodata"); self.chk_nodata_transp.setChecked(True)
        g2b.addWidget(self.chk_nodata_transp, 1, 1)
        cont_v.addWidget(grp_cmap)
        cont_v.addStretch(1)
        self.tab_color_mode.addTab(tab_cont, "Continuous")

        # Sub-Tab Discrete
        tab_disc = QWidget()
        disc_outer = QVBoxLayout(tab_disc); disc_outer.setContentsMargins(8, 8, 8, 8); disc_outer.setSpacing(8)

        grp_class_setup = create_groupbox("Class Setup")
        gcs = QVBoxLayout(grp_class_setup); gcs.setContentsMargins(10, 14, 10, 10); gcs.setSpacing(6)
        self.btn_scan_classes = QPushButton("SCAN GRIDCODES"); self.btn_scan_classes.setMinimumHeight(30); self.btn_scan_classes.clicked.connect(self._scan_discrete_classes)
        gcs.addWidget(self.btn_scan_classes)

        dec_row = QHBoxLayout()
        dec_row.addWidget(QLabel("Decimals:")); self.sp_global_decimals = QSpinBox(); self.sp_global_decimals.setRange(0, 6); self.sp_global_decimals.setValue(2); self.sp_global_decimals.setFixedWidth(50)
        dec_row.addWidget(self.sp_global_decimals)
        btn_apply_dec = QPushButton("Apply"); btn_apply_dec.setFixedHeight(26); btn_apply_dec.clicked.connect(self._apply_global_decimals)
        dec_row.addWidget(btn_apply_dec); dec_row.addStretch()
        gcs.addLayout(dec_row)

        nd_row = QHBoxLayout()
        nd_row.addWidget(QLabel("Nodata:")); self.btn_nodata_color = QPushButton(); self.btn_nodata_color.setFixedSize(26, 26); self.btn_nodata_color.setStyleSheet("background-color: transparent; border: 1px dashed #888; border-radius:3px;")
        self.btn_nodata_color.clicked.connect(self._pick_nodata_color)
        self.le_nodata_hex = QLineEdit("transparent"); self.le_nodata_hex.setFixedWidth(90); self.le_nodata_hex.setReadOnly(True)
        nd_row.addWidget(self.btn_nodata_color); nd_row.addWidget(self.le_nodata_hex); nd_row.addStretch()
        gcs.addLayout(nd_row)

        self.chk_disc_legend = QCheckBox("Show Discrete Legend"); self.chk_disc_legend.setChecked(True)
        gcs.addWidget(self.chk_disc_legend)
        disc_outer.addWidget(grp_class_setup)

        grp_classes = create_groupbox("Classes")
        gcl = QVBoxLayout(grp_classes); gcl.setContentsMargins(10, 14, 10, 10); gcl.setSpacing(6)
        self._disc_scroll = QScrollArea(); self._disc_scroll.setWidgetResizable(True); self._disc_scroll.setMinimumHeight(140); self._disc_scroll.setFrameShape(QScrollArea.StyledPanel)
        self._disc_classes_container = QWidget(); self._disc_classes_layout = QVBoxLayout(self._disc_classes_container)
        self._disc_classes_layout.setContentsMargins(4, 4, 4, 4); self._disc_classes_layout.setSpacing(4); self._disc_classes_layout.addStretch()
        self._disc_scroll.setWidget(self._disc_classes_container)
        gcl.addWidget(self._disc_scroll)
        disc_outer.addWidget(grp_classes, stretch=1)
        self.tab_color_mode.addTab(tab_disc, "Discrete")

        # QTabWidget/QStackedWidget sizes itself to the TALLEST of its pages
        # (Discrete, with its scrollable class list) even while the shorter
        # Continuous page is the one showing — which is what was leaving a
        # large empty gap above "Legend Layout Settings" below. Capping the
        # height here keeps both sub-tabs compact and pulls the legend
        # settings up right underneath them.
        self.tab_color_mode.setMaximumHeight(340)

        cbar_vbox.addWidget(self.tab_color_mode)

        grp_leg_pos = create_groupbox("Legend — Position && Size")
        gcb1 = QGridLayout(grp_leg_pos); gcb1.setSpacing(6); gcb1.setContentsMargins(10, 14, 10, 10)
        gcb1.setColumnStretch(0, 0); gcb1.setColumnStretch(1, 1)
        gcb1.addWidget(QLabel("Orientation:"), 0, 0); self.cb_orient = QComboBox(); self.cb_orient.addItems(["horizontal", "vertical"]); gcb1.addWidget(self.cb_orient, 0, 1)
        gcb1.addWidget(QLabel("Position X/Y:"), 1, 0)
        self.sp_leg_x = QDoubleSpinBox(); self.sp_leg_x.setRange(0, 1); self.sp_leg_x.setSingleStep(0.01); self.sp_leg_x.setValue(0.20)
        self.sp_leg_y = QDoubleSpinBox(); self.sp_leg_y.setRange(0, 1); self.sp_leg_y.setSingleStep(0.01); self.sp_leg_y.setValue(0.05)
        gcb1.addLayout(_stacked_pair(self.sp_leg_x, "X:", self.sp_leg_y, "Y:"), 1, 1)
        gcb1.addWidget(QLabel("Length/Thickness:"), 2, 0)
        self.sp_leg_w = QDoubleSpinBox(); self.sp_leg_w.setRange(0.01, 1); self.sp_leg_w.setSingleStep(0.01); self.sp_leg_w.setValue(0.60)
        self.sp_leg_h = QDoubleSpinBox(); self.sp_leg_h.setRange(0.01, 1); self.sp_leg_h.setSingleStep(0.01); self.sp_leg_h.setValue(0.03)
        gcb1.addLayout(_stacked_pair(self.sp_leg_w, "L:", self.sp_leg_h, "T:"), 2, 1)
        gcb1.addWidget(QLabel("End Style:"), 3, 0); self.cb_legend_style = QComboBox(); self.cb_legend_style.addItems(["Both Pointed", "Right Pointed (Max)", "Left Pointed (Min)", "Box (Standard)"]); self.cb_legend_style.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon); self.cb_legend_style.view().setMinimumWidth(220); gcb1.addWidget(self.cb_legend_style, 3, 1)
        cbar_vbox.addWidget(grp_leg_pos)

        grp_leg_lbl = create_groupbox("Legend — Labels && Ticks")
        gcb2 = QGridLayout(grp_leg_lbl); gcb2.setSpacing(6); gcb2.setContentsMargins(10, 14, 10, 10)
        gcb2.setColumnStretch(0, 0); gcb2.setColumnStretch(1, 1)
        gcb2.addWidget(QLabel("Label Text:"), 0, 0); self.le_cbar_label = QLineEdit("Value"); gcb2.addWidget(self.le_cbar_label, 0, 1)
        gcb2.addWidget(QLabel("Label Style:"), 1, 0); lbl_style_lay = QHBoxLayout(); self.chk_cbar_lbl_bold = QCheckBox("Bold"); self.chk_cbar_lbl_bold.setChecked(True); self.chk_cbar_lbl_italic = QCheckBox("Italic"); lbl_style_lay.addWidget(self.chk_cbar_lbl_bold); lbl_style_lay.addWidget(self.chk_cbar_lbl_italic); lbl_style_lay.addStretch(); gcb2.addLayout(lbl_style_lay, 1, 1)
        gcb2.addWidget(QLabel("Label Position:"), 2, 0); self.cb_cbar_lbl_pos = QComboBox(); self.cb_cbar_lbl_pos.addItems(["Default", "Top", "Bottom", "Right", "Left"]); gcb2.addWidget(self.cb_cbar_lbl_pos, 2, 1)
        gcb2.addWidget(QLabel("Label Size:"), 3, 0); self.sp_leg_lbl_size = QSpinBox(); self.sp_leg_lbl_size.setRange(6, 30); self.sp_leg_lbl_size.setValue(10); gcb2.addWidget(self.sp_leg_lbl_size, 3, 1)
        gcb2.addWidget(QLabel("Label Padding:"), 4, 0); self.sp_leg_pad_label = QSpinBox(); self.sp_leg_pad_label.setRange(-50, 100); self.sp_leg_pad_label.setValue(5); gcb2.addWidget(self.sp_leg_pad_label, 4, 1)

        sep_leg = QFrame(); sep_leg.setFrameShape(QFrame.HLine)
        gcb2.addWidget(sep_leg, 5, 0, 1, 2)

        gcb2.addWidget(QLabel("Tick Size:"), 6, 0); tick_sz_lay = QHBoxLayout(); tick_sz_lay.setContentsMargins(0, 0, 0, 0); self.sp_leg_tick_size = QSpinBox(); self.sp_leg_tick_size.setRange(6, 30); self.sp_leg_tick_size.setValue(9); tick_sz_lay.addWidget(self.sp_leg_tick_size); self.chk_cbar_tick_bold = QCheckBox("Bold"); tick_sz_lay.addWidget(self.chk_cbar_tick_bold); self.chk_cbar_tick_italic = QCheckBox("Italic"); tick_sz_lay.addWidget(self.chk_cbar_tick_italic); tick_sz_lay.addStretch(); gcb2.addLayout(tick_sz_lay, 6, 1)
        self.chk_ticks = QCheckBox("Dynamic Ticks"); self.chk_ticks.setChecked(False); gcb2.addWidget(self.chk_ticks, 7, 0, 1, 2)
        gcb2.addWidget(QLabel("Tick Count:"), 8, 0); self.sp_tick_count = QSpinBox(); self.sp_tick_count.setRange(2, 30); self.sp_tick_count.setValue(5); gcb2.addWidget(self.sp_tick_count, 8, 1)
        gcb2.addWidget(QLabel("Tick Padding:"), 9, 0); self.sp_leg_pad_tick = QSpinBox(); self.sp_leg_pad_tick.setRange(-50, 100); self.sp_leg_pad_tick.setValue(2); gcb2.addWidget(self.sp_leg_pad_tick, 9, 1)
        gcb2.addWidget(QLabel("Tick Decimals:"), 10, 0); self.sp_cbar_decimals = QSpinBox(); self.sp_cbar_decimals.setRange(0, 8); self.sp_cbar_decimals.setValue(4); gcb2.addWidget(self.sp_cbar_decimals, 10, 1)
        cbar_vbox.addWidget(grp_leg_lbl)

        cbar_vbox.addStretch(1)

        self.tab_right.addTab(_make_tab_scroll(tab_cbar), "Colorbar")

        self.tab_right.tabBar().setUsesScrollButtons(True)
        self.tab_right.tabBar().setElideMode(Qt.ElideRight)
        self.main_splitter.addWidget(self.tab_right)

        # Only two panes now (center map + right panel) — the left panel
        # was removed and its Data/Layers tabs moved onto tab_right.
        self.main_splitter.setStretchFactor(0, 1)
        self.main_splitter.setStretchFactor(1, 0)
        self.main_splitter.setSizes([1100, 260])
        main_layout.addWidget(self.main_splitter)

        # Safety net: every combobox in the right panel gets a popup that's
        # at least 200px wide (even ones not explicitly tuned above), so a
        # narrow closed box never means truncated items in the dropdown.
        for combo in self.tab_right.findChildren(QComboBox):
            combo.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
            if combo.view().minimumWidth() < 200:
                combo.view().setMinimumWidth(200)

        self._apply_tooltips()
        self._toggle_stretch_opts()
        self._update_cmap_preview()
        self._toggle_canvas_size_opts()

    def _set_status(self, text, kind="info"):
        # Status kind is conveyed with a short text tag instead of an icon,
        # keeping the status bar plain text.
        prefix_map = {
            "ready": "[OK] ",
            "loading": "[...] ",
            "error": "[ERROR] ",
            "info": "",
        }
        self.lbl_status.setText(prefix_map.get(kind, "") + text)

        if kind == "loading": self.progress_status.show()
        else: self.progress_status.hide()

    def _apply_tooltips(self):
        tips = [
            (self.rb_single, "Tampilkan satu band raster (grayscale/berwarna via colormap)"),
            (self.rb_rgb, "Gabungkan 3 band terpisah menjadi komposit warna RGB"),
            (self.sp_maxpx, "Batas jumlah piksel (dalam ribuan) yang dibaca — nilai lebih kecil = render lebih cepat tapi resolusi turun"),
            (self.cb_vec_symbology, "Single Symbol: satu warna untuk semua fitur. Categorized: warna berbeda per nilai unik pada suatu kolom"),
            (self.chk_vec_fill, "Aktifkan/nonaktifkan isi warna pada poligon (tidak berlaku untuk garis/titik)"),
            (self.sp_vec_fillalpha, "Transparansi isi warna: 0 = tembus pandang penuh, 1 = solid"),
            (self.btn_vec_classify, "Cari semua nilai unik pada kolom terpilih dan beri masing-masing warna otomatis"),
            (self.cb_stretch, "Actual Min-Max: pakai nilai data asli. Percentile: potong nilai ekstrem/outlier. Manual: masukkan sendiri batas vmin/vmax"),
            (self.sp_pmin, "Persentil bawah — nilai di bawah ini dianggap 'ekstrem' dan dipotong dari rentang warna"),
            (self.sp_pmax, "Persentil atas — nilai di atas ini dianggap 'ekstrem' dan dipotong dari rentang warna"),
            (self.le_vmin, "Batas bawah nilai data yang dipetakan ke ujung colormap (mode Manual Min-Max)"),
            (self.le_vmax, "Batas atas nilai data yang dipetakan ke ujung colormap (mode Manual Min-Max)"),
            (self.chk_reverse_cmap, "Balik urutan warna pada colormap (mis. gelap-ke-terang jadi terang-ke-gelap)"),
            (self.chk_nodata_transp, "Piksel nodata/kosong ditampilkan transparan, bukan berwarna solid"),
            (self.btn_scan_classes, "Pindai semua nilai gridcode unik pada raster untuk dibuatkan baris kelas warna Discrete"),
            (self.cb_basemap, "Peta dasar dari internet (perlu koneksi) yang digambar di belakang layer-layer kamu"),
            (self.chk_show_attrib, "Tampilkan teks kredit/sumber peta dasar (wajib secara lisensi untuk sebagian besar provider)"),
            (self.chk_north_arrow, "Tampilkan tanda arah utara (panah + huruf N) di atas peta"),
            (self.cb_scalebar_style, "Simple Line: garis + tick di ujung. Alternating Bar: kotak hitam-putih berselang seperti peta cetak"),
            (self.cb_scalebar_orient, "Arah scale bar digambar: mendatar (Horizontal) atau tegak (Vertical)"),
            (self.sp_scalebar_segments, "Jumlah kotak hitam-putih berselang (hanya berlaku untuk style Alternating Bar)"),
            (self.chk_scalebar, "Tampilkan skala jarak di peta; panjang otomatis dihitung sesuai sistem koordinat layer"),
            (self.cb_scalebar_unit, "Auto: pilih meter/kilometer otomatis sesuai panjang. Atau paksa satu satuan"),
            (self.cb_coord_format, "Format angka koordinat pada sumbu: DMS (derajat-menit-detik), DM, Decimal Degree, atau default (mis. meter UTM)"),
            (self.sp_coord_decimals, "Jumlah angka di belakang koma untuk label koordinat"),
            (self.sp_xlabel_rotation, "Sudut kemiringan (derajat) label angka pada sumbu X"),
            (self.sp_ylabel_rotation, "Sudut kemiringan (derajat) label angka pada sumbu Y"),
            (self.cb_grid_style, "Gaya garis grid koordinat: solid, putus-putus, atau titik-titik"),
            (self.le_xaxis_label, "Judul sumbu X (mis. 'Longitude'); kosongkan untuk menyembunyikan"),
            (self.le_yaxis_label, "Judul sumbu Y (mis. 'Latitude'); kosongkan untuk menyembunyikan"),
            (self.cb_orient, "Arah colorbar: horizontal (mendatar) atau vertical (tegak)"),
            (self.cb_legend_style, "Bentuk ujung colorbar: runcing di satu/kedua sisi (menandakan nilai di luar rentang) atau kotak biasa"),
            (self.cb_cbar_lbl_pos, "Posisi teks label colorbar relatif terhadap batangnya: default menempel sisi, atau dipindah ke atas/bawah/kiri/kanan"),
            (self.chk_ticks, "Biarkan matplotlib menentukan posisi angka tick colorbar secara otomatis, alih-alih jumlah tetap"),
            (self.sp_tick_count, "Jumlah angka tick yang ditampilkan pada colorbar (jika Dynamic Ticks nonaktif)"),
            (self.sp_leg_pad_label, "Jarak (padding) antara teks label colorbar dan batang colorbar"),
            (self.sp_leg_pad_tick, "Jarak (padding) antara angka tick dan batang colorbar"),
            (self.sp_cbar_decimals, "Jumlah angka di belakang koma untuk angka pada colorbar"),
            (self.chk_disc_legend, "Tampilkan kotak legenda berisi warna + label untuk tiap kelas gridcode (mode Discrete)"),
        ]
        for widget, text in tips:
            try:
                widget.setToolTip(text)
            except Exception as exc:
                # Tooltip assignment can only fail if the widget was already
                # deleted by Qt (e.g. during teardown) — non-fatal, but log
                # it instead of swallowing it silently.
                QgsMessageLog.logMessage(f"RasterViz: could not set tooltip: {exc}", "RasterViz", Qgis.Info)

    def _fit_view_map(self):
        self.map_scroll.setWidgetResizable(True)
        self.canvas_map.setMinimumSize(0, 0)
        self.canvas_map.setMaximumSize(16777215, 16777215)
        self.canvas_map.updateGeometry()

    # ------------------------------------------------------------------
    # CANVAS SIZE (paper presets: A0-A5, US Letter/Legal/Tabloid, Custom)
    # ------------------------------------------------------------------
    # mm dimensions, portrait (width, height)
    _PAPER_SIZES_MM = {
        "A0": (841, 1189), "A1": (594, 841), "A2": (420, 594),
        "A3": (297, 420), "A4": (210, 297), "A5": (148, 210),
        "US Letter": (215.9, 279.4), "US Legal": (215.9, 355.6),
        "US Tabloid": (279.4, 431.8),
    }

    def _toggle_canvas_size_opts(self):
        choice = self.cb_paper_size.currentText()
        is_fit = (choice == "Fit to Window")
        is_custom = (choice == "Custom")
        self.cb_paper_orient.setEnabled(not is_fit and not is_custom)
        self.sp_custom_w_cm.setEnabled(is_custom)
        self.sp_custom_h_cm.setEnabled(is_custom)
        if is_fit:
            self.lbl_canvas_size_info.setText("Fit to Window: canvas follows the app window size.")
        elif is_custom:
            self.lbl_canvas_size_info.setText("Custom: exact width/height in centimetres, used for both preview and export.")
        else:
            self.lbl_canvas_size_info.setText(f"{choice}: fixed paper size ({self.cb_paper_orient.currentText().lower()}), exported at the DPI above.")

    def _apply_canvas_size(self):
        choice = self.cb_paper_size.currentText()

        if choice == "Fit to Window":
            self._canvas_fixed_size_in = None
            self._fit_view_map()
            self._set_status("Canvas set to fit the window (dynamic size).", "ready")
            self._trigger_live_update()
            return

        if choice == "Custom":
            w_in = self.sp_custom_w_cm.value() / 2.54
            h_in = self.sp_custom_h_cm.value() / 2.54
        else:
            w_mm, h_mm = self._PAPER_SIZES_MM[choice]
            w_in, h_in = w_mm / 25.4, h_mm / 25.4
            if self.cb_paper_orient.currentText() == "Landscape":
                w_in, h_in = max(w_in, h_in), min(w_in, h_in)
            else:
                w_in, h_in = min(w_in, h_in), max(w_in, h_in)

        self._canvas_fixed_size_in = (w_in, h_in)

        # Preview at matplotlib's default screen DPI (100) so the on-screen
        # canvas is a true-to-proportion, scrollable stand-in for the real
        # paper size; the actual export uses the DPI spinbox above.
        preview_dpi = 100
        px_w = max(1, int(round(w_in * preview_dpi)))
        px_h = max(1, int(round(h_in * preview_dpi)))
        self.map_scroll.setWidgetResizable(False)
        self.canvas_map.setMaximumSize(16777215, 16777215)
        self.canvas_map.setFixedSize(px_w, px_h)

        label = choice if choice == "Custom" else f"{choice} {self.cb_paper_orient.currentText()}"
        self._set_status(f"Canvas set to {label} ({w_in:.2f}in x {h_in:.2f}in).", "ready")
        self._toggle_canvas_size_opts()
        self._trigger_live_update()

    def _zoom_in_map(self): self._apply_zoom_map(1.2)
    def _zoom_out_map(self): self._apply_zoom_map(0.8)

    def _apply_zoom_map(self, factor):
        if self.map_scroll.widgetResizable():
            curr_size = self.canvas_map.size()
            self.map_scroll.setWidgetResizable(False)
            self.canvas_map.setFixedSize(curr_size)
        current_w = self.canvas_map.width()
        current_h = self.canvas_map.height()
        self.canvas_map.setFixedSize(int(current_w * factor), int(current_h * factor))

    def _add_layer_item(self, layer_id, layer_name):
        layer = self._layers_dict.get(layer_id)
        # Layer type is shown as a plain text tag instead of an icon.
        if isinstance(layer, RasterLayer): tag = "[Raster] "
        elif isinstance(layer, VectorLayer): tag = "[Vector] "
        else: tag = ""
        item = QListWidgetItem(tag + layer_name)
        item.setFlags(item.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsDragEnabled)
        item.setCheckState(Qt.Checked)
        item.setData(Qt.UserRole, layer_id)
        self.list_layers.insertItem(0, item)
        self.list_layers.setCurrentItem(item)

    def populate_layers(self):
        self.list_layers.clear()
        layers = list(RASTER_REGISTRY.mapLayers().values())
        for lyr in layers:
            self._add_layer_item(lyr.id(), lyr.name())

    def _open_raster_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Open Raster File", "", SUPPORTED_RASTER_FILTER)
        if path:
            rlayer = RasterLayer(path, os.path.basename(path))
            if rlayer.isValid():
                self._layers_dict[rlayer.id()] = rlayer
                self._add_layer_item(rlayer.id(), rlayer.name())
            else:
                QMessageBox.warning(self, "Error", f"Failed to load raster file.\n\n{rlayer.error_message() or ''}")

    def _open_vector_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Open Vector File", "", SUPPORTED_VECTOR_FILTER)
        if path:
            vlayer = VectorLayer(path)
            if vlayer.isValid():
                self._layers_dict[vlayer.id()] = vlayer
                self._add_layer_item(vlayer.id(), vlayer.name())
            else:
                QMessageBox.warning(self, "Error", f"Failed to load vector file.\n\n{vlayer.error or ''}")

    def _remove_layer(self):
        row = self.list_layers.currentRow()
        if row < 0: return
        lid = self.list_layers.item(row).data(Qt.UserRole)
        self._remove_layer_by_id(lid)

    def _remove_layer_by_id(self, lid):
        for i in range(self.list_layers.count()):
            if self.list_layers.item(i).data(Qt.UserRole) == lid:
                self.list_layers.takeItem(i)
                break
        self._layers_dict.pop(lid, None)
        self._map_cache.pop(lid, None)
        if self._current_vector_lid == lid:
            self._current_vector_lid = None
            self.grp_vecstyle.setVisible(False)
        if self.list_layers.count() == 0:
            self._cached_ext = None
            self._view_ext = None
        self._trigger_live_update()

    def _scan_discrete_classes(self):
        if self._cached_arr is None:
            QMessageBox.warning(self, "No Data", "Click 'READ DATA & RENDER' first before scanning gridcodes.")
            return
        valid = self._cached_arr[np.isfinite(self._cached_arr)]
        if len(valid) == 0:
            QMessageBox.warning(self, "Empty Data", "No valid (finite) pixel values detected.")
            return
        unique_vals = np.unique(valid)
        if len(unique_vals) > 100:
            ret = QMessageBox.question(
                self, "Many Classes", f"{len(unique_vals)} unique values detected.\nContinue building {len(unique_vals)} class rows?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No,
            )
            if ret != QMessageBox.Yes: return
        self._build_discrete_rows(unique_vals)
        self._trigger_live_update()

    def _build_discrete_rows(self, unique_vals):
        for row in self._discrete_rows:
            row.setParent(None); row.deleteLater()
        self._discrete_rows.clear()
        palette = DiscreteClassRow.DEFAULT_PALETTE
        current_dec = self.sp_global_decimals.value()
        for i, v in enumerate(unique_vals):
            color = palette[i % len(palette)]
            is_int = float(v).is_integer()
            label = str(int(v)) if is_int else f"{v:.{current_dec}f}"
            row_w = DiscreteClassRow(v, color_hex=color, label=label, decimals=current_dec, parent=self._disc_classes_container)
            row_w.le_label.textChanged.connect(self._trigger_live_update)
            row_w.sp_decimals.valueChanged.connect(self._trigger_live_update)
            row_w.le_hex.textChanged.connect(self._trigger_live_update)
            row_w.btn_color.clicked.connect(self._trigger_live_update)
            n = self._disc_classes_layout.count()
            self._disc_classes_layout.insertWidget(n - 1, row_w)
            self._discrete_rows.append(row_w)

    def _apply_global_decimals(self):
        dec = self.sp_global_decimals.value()
        for row in self._discrete_rows:
            row.sp_decimals.blockSignals(True)
            row.sp_decimals.setValue(dec)
            row.sp_decimals.blockSignals(False)
        self._trigger_live_update()

    def _pick_nodata_color(self):
        initial = QColor(self._nodata_color) if QColor(self._nodata_color).isValid() else QColor(Qt.transparent)
        col = QColorDialog.getColor(initial, self, "Choose Nodata Colour", QColorDialog.ShowAlphaChannel)
        if col.isValid():
            if col.alpha() == 0:
                self._nodata_color = "#00000000"
                self.btn_nodata_color.setStyleSheet("background-color: transparent; border: 1px dashed #888; border-radius:3px;")
                self.le_nodata_hex.setText("transparent")
            else:
                self._nodata_color = col.name()
                self.btn_nodata_color.setStyleSheet(f"background-color:{self._nodata_color}; border:1px solid #888; border-radius:3px;")
                self.le_nodata_hex.setText(self._nodata_color)
        self._trigger_live_update()

    def _is_discrete_mode(self): return self.tab_color_mode.currentIndex() == 1
    def _cmap_prev(self): self.cmap_idx = (self.cmap_idx - 1) % len(COLORMAPS); self._update_cmap_preview(); self._trigger_live_update()
    def _cmap_next(self): self.cmap_idx = (self.cmap_idx + 1) % len(COLORMAPS); self._update_cmap_preview(); self._trigger_live_update()
    def _on_reverse_toggled(self): self._update_cmap_preview(); self._trigger_live_update()

    def _update_cmap_preview(self):
        cmap_name = COLORMAPS[self.cmap_idx]
        display_name = cmap_name.replace("_", " ")
        self.lbl_cmap_name.setText(display_name)
        
        w, h = 250, 28
        pixmap = QPixmap(w, h)
        painter = QPainter(pixmap)
        
        try:
            cmap = matplotlib.colormaps[cmap_name]
            if self.chk_reverse_cmap.isChecked(): cmap = cmap.reversed()
        except Exception:
            cmap = matplotlib.colormaps["viridis"]
            
        for x in range(w):
            c = cmap(x / max(1, w - 1))
            painter.setPen(QColor(int(c[0] * 255), int(c[1] * 255), int(c[2] * 255)))
            painter.drawLine(x, 0, x, h)
            
        painter.setPen(QColor("#2b2b2b"))
        painter.drawRect(0, 0, w - 1, h - 1)
        painter.end()
        self.lbl_cmap_preview.setPixmap(pixmap)
        self.lbl_cmap_preview.setToolTip(display_name)

    def _connect_live_updates(self):
        self.cb_orient.currentTextChanged.connect(self._auto_position_legend)
        for w in [self.cb_stretch, self.cb_legend_style, self.cb_grid_style, self.cb_bg_color, self.cb_coord_format, self.cb_font_family, self.cb_cbar_lbl_pos, self.cb_title_align, self.cb_basemap, self.cb_scalebar_unit, self.cb_north_style, self.cb_scalebar_style, self.cb_scalebar_orient]:
            w.currentIndexChanged.connect(self._trigger_live_update)
        for s in [self.sp_pmin, self.sp_pmax, self.sp_map_x, self.sp_map_y, self.sp_map_w, self.sp_map_h, self.sp_leg_x, self.sp_leg_y, self.sp_leg_w, self.sp_leg_h, self.sp_coord_size, self.sp_title_size, self.sp_sub_size, self.sp_leg_lbl_size, self.sp_leg_tick_size, self.sp_tick_count, self.sp_leg_pad_label, self.sp_leg_pad_tick, self.sp_xlabel_rotation, self.sp_ylabel_rotation, self.sp_xtick_count, self.sp_ytick_count, self.sp_coord_decimals, self.sp_cbar_decimals, self.sp_raster_alpha, self.sp_north_x, self.sp_north_y, self.sp_north_size, self.sp_scalebar_x, self.sp_scalebar_y, self.sp_scalebar_length, self.sp_scalebar_segments]:
            s.valueChanged.connect(self._trigger_live_update)
        for c in [self.chk_legend, self.chk_ticks, self.chk_axes, self.chk_grid, self.chk_nodata_transp, self.chk_disc_legend,
                  self.chk_title_bold, self.chk_title_italic, self.chk_subtitle_bold, self.chk_subtitle_italic,
                  self.chk_axislbl_bold, self.chk_axislbl_italic,
                  self.chk_cbar_lbl_bold, self.chk_cbar_lbl_italic, self.chk_cbar_tick_bold, self.chk_cbar_tick_italic,
                  self.chk_north_arrow, self.chk_scalebar]:
            c.toggled.connect(self._trigger_live_update)
        for le in [self.le_vmin, self.le_vmax, self.le_cbar_label, self.le_title, self.le_subtitle, self.le_xaxis_label, self.le_yaxis_label]:
            le.textChanged.connect(self._trigger_live_update)
        self.tab_color_mode.currentChanged.connect(self._trigger_live_update)

    def _auto_position_legend(self, orient):
        self._is_updating = True
        if orient == "vertical":
            self.sp_leg_x.setValue(0.88); self.sp_leg_y.setValue(0.20); self.sp_leg_w.setValue(0.60); self.sp_leg_h.setValue(0.03)
        else:
            self.sp_leg_x.setValue(0.20); self.sp_leg_y.setValue(0.05); self.sp_leg_w.setValue(0.60); self.sp_leg_h.setValue(0.03)
        self._is_updating = False
        self._trigger_live_update()

    def _on_layer_changed(self, current=None, previous=None):
        item = current if current is not None else self.list_layers.currentItem()
        if not item:
            self.grp_vecstyle.setVisible(False)
            self._current_vector_lid = None
            return
        lid = item.data(Qt.UserRole)
        lyr = self._layers_dict.get(lid)
        if isinstance(lyr, RasterLayer):
            nb = lyr.bandCount()
            for sp in [self.sp_band, self.sp_r, self.sp_g, self.sp_b]: sp.setMaximum(max(1, nb))
            self.grp_vecstyle.setVisible(False)
            self._current_vector_lid = None
        elif isinstance(lyr, VectorLayer):
            self._current_vector_lid = lid
            self._load_vector_style_into_panel(lyr)
            self.grp_vecstyle.setVisible(True)
        else:
            self.grp_vecstyle.setVisible(False)
            self._current_vector_lid = None

    def _show_layer_context_menu(self, pos):
        item = self.list_layers.itemAt(pos)
        if item is None: return
        self.list_layers.setCurrentItem(item)
        lid = item.data(Qt.UserRole)
        layer = self._layers_dict.get(lid)

        menu = QMenu(self)
        act_zoom = menu.addAction("Zoom to Extent")
        act_props = menu.addAction("Vector Symbology…") if isinstance(layer, VectorLayer) else None
        menu.addSeparator()
        act_remove = menu.addAction("Remove Layer")

        chosen = menu.exec_(self.list_layers.viewport().mapToGlobal(pos))
        if chosen is None: return
        if chosen == act_zoom:
            self._zoom_to_layer_extent(lid)
        elif act_props is not None and chosen == act_props:
            self.grp_vecstyle.setVisible(True)
        elif chosen == act_remove:
            self._remove_layer_by_id(lid)

    def _zoom_to_layer_extent(self, lid):
        entry = self._map_cache.get(lid)
        if entry is None:
            QMessageBox.information(self, "No Data", "Click 'READ DATA & RENDER' first so this layer's extent is available.")
            return
        _, _, ext = entry
        self._view_ext = ext
        self._set_status("Zoomed to selected layer's extent.", "ready")
        self._trigger_live_update()

    def _zoom_to_full_extent(self):
        full_ext = self._compute_full_extent()
        if full_ext is None:
            QMessageBox.information(self, "No Data", "Click 'READ DATA & RENDER' first so layer extents are available.")
            return
        self._cached_ext = full_ext
        self._view_ext = None
        self._set_status("Reset to full extent (all layers).", "ready")
        self._trigger_live_update()

    def _set_color_button(self, btn, hex_color):
        btn.setProperty("hexColor", hex_color)
        btn.setStyleSheet(f"background-color:{hex_color}; border:1px solid #888; border-radius:3px;")

    def _pick_vec_fill_color(self):
        self._pick_color_for_button(self.btn_vec_fillcolor)

    def _pick_vec_outline_color(self):
        self._pick_color_for_button(self.btn_vec_outlinecolor)

    def _pick_color_for_button(self, btn):
        current = btn.property("hexColor") or "#888888"
        initial = QColor(current) if QColor(current).isValid() else QColor("#888888")
        col = QColorDialog.getColor(initial, self, "Choose Colour")
        if col.isValid():
            self._set_color_button(btn, col.name())
            self._apply_vector_style()

    def _toggle_vec_symbology_mode(self):
        categorized = self.cb_vec_symbology.currentIndex() == 1
        self.lbl_vec_field.setVisible(categorized)
        self.cb_vec_field.setVisible(categorized)
        self.btn_vec_classify.setVisible(categorized)
        self._vec_cat_scroll.setVisible(categorized)
        if not self._is_updating:
            self._apply_vector_style()

    def _load_vector_style_into_panel(self, lyr):
        self._is_updating = True
        self.cb_vec_symbology.setCurrentIndex(0 if lyr.symbology_mode == "single" else 1)
        self.chk_vec_fill.setChecked(lyr.fill_enabled)
        self._set_color_button(self.btn_vec_fillcolor, lyr.fill_color)
        self.sp_vec_fillalpha.setValue(lyr.fill_alpha)
        self._set_color_button(self.btn_vec_outlinecolor, lyr.outline_color)
        self.sp_vec_outlinewidth.setValue(lyr.outline_width)

        self.cb_vec_field.blockSignals(True)
        self.cb_vec_field.clear()
        self.cb_vec_field.addItems(lyr.field_names())
        if lyr.category_field and lyr.category_field in lyr.field_names():
            self.cb_vec_field.setCurrentText(lyr.category_field)
        self.cb_vec_field.blockSignals(False)

        self._rebuild_category_rows(lyr)
        self._is_updating = False
        self._toggle_vec_symbology_mode()

    def _classify_vector_field(self):
        lyr = self._layers_dict.get(self._current_vector_lid)
        if lyr is None: return
        field = self.cb_vec_field.currentText()
        if not field:
            QMessageBox.warning(self, "No Field", "Choose a field to classify first.")
            return
        lyr.category_field = field
        lyr.category_colors = {}
        lyr.ensure_category_colors(field)
        self._rebuild_category_rows(lyr)
        self._apply_vector_style()

    def _rebuild_category_rows(self, lyr):
        for row in self._vec_category_rows:
            row.setParent(None); row.deleteLater()
        self._vec_category_rows.clear()
        if not lyr.category_field: return
        for val in lyr.unique_values(lyr.category_field):
            color = lyr.category_colors.get(val, DiscreteClassRow.DEFAULT_PALETTE[0])
            row_w = VectorCategoryRow(val, color_hex=color, parent=self._vec_cat_container)
            row_w.btn_color.clicked.connect(lambda _checked=False, w=row_w: self._on_category_color_changed(w))
            n = self._vec_cat_layout.count()
            self._vec_cat_layout.insertWidget(n - 1, row_w)
            self._vec_category_rows.append(row_w)

    def _on_category_color_changed(self, row_w):
        lyr = self._layers_dict.get(self._current_vector_lid)
        if lyr is not None:
            lyr.category_colors[row_w.value] = row_w.get_color()
        self._trigger_live_update()

    def _apply_vector_style(self):
        if self._is_updating: return
        lyr = self._layers_dict.get(self._current_vector_lid)
        if lyr is None: return
        lyr.symbology_mode = "categorized" if self.cb_vec_symbology.currentIndex() == 1 else "single"
        lyr.fill_enabled = self.chk_vec_fill.isChecked()
        lyr.fill_color = self.btn_vec_fillcolor.property("hexColor") or lyr.fill_color
        lyr.fill_alpha = self.sp_vec_fillalpha.value()
        lyr.outline_color = self.btn_vec_outlinecolor.property("hexColor") or lyr.outline_color
        lyr.outline_width = self.sp_vec_outlinewidth.value()
        if lyr.symbology_mode == "categorized":
            field = self.cb_vec_field.currentText()
            if field:
                lyr.category_field = field
                lyr.ensure_category_colors(field)
        self._trigger_live_update()

    def _toggle_band_mode(self):
        single = self.rb_single.isChecked()
        self.lbl_band.setVisible(single); self.sp_band.setVisible(single)
        self.btn_cmap_prev.setEnabled(single); self.btn_cmap_next.setEnabled(single)
        self.chk_reverse_cmap.setEnabled(single)
        for w in [self.lbl_r, self.sp_r, self.lbl_g, self.sp_g, self.lbl_b, self.sp_b]: w.setVisible(not single)
        self._cached_arr = None; self._cached_rgb = None

    def _toggle_stretch_opts(self):
        mode = self.cb_stretch.currentText()
        pct = "Percentile" in mode; manual = "Manual" in mode
        self.lbl_pmin.setVisible(pct); self.sp_pmin.setVisible(pct)
        self.lbl_pmax.setVisible(pct); self.sp_pmax.setVisible(pct)
        self.lbl_vmin.setVisible(manual); self.le_vmin.setVisible(manual)
        self.lbl_vmax.setVisible(manual); self.le_vmax.setVisible(manual)

    def _read_band(self, lyr, band_no, max_px_k=1000, dst_crs=None, nearest=False):
        return lyr.read_band(band_no, max_px_k=max_px_k, dst_crs=dst_crs, nearest=nearest)

    def _resolve_target_crs(self):
        """Pick the single shared CRS every layer gets reprojected to for
        this render session (rasters via `read_band(dst_crs=...)`, vectors
        via `render_vector_layer(dst_crs=...)`).

        Rule: the CRS of the topmost layer in the layer list (list index 0
        — `_live_update` iterates the list back-to-front, so index 0 is
        drawn last/on top). This is resolved once, up front, rather than
        picked up on-the-fly from whichever layer happens to be processed
        first, so it's an explicit, consistent target for every layer in
        the loop below — including the very first one.
        """
        for i in range(self.list_layers.count()):
            item = self.list_layers.item(i)
            lid = item.data(Qt.UserRole)
            layer = self._layers_dict.get(lid)
            if not layer: continue
            if isinstance(layer, RasterLayer):
                return layer.crs()
            if isinstance(layer, VectorLayer):
                return crs_display_string(layer.crs())
        return None

    def _compute_full_extent(self):
        if not self._map_cache: return None
        xmins, ymins, xmaxs, ymaxs = [], [], [], []
        for _, _, ext in self._map_cache.values():
            xmins.append(ext.xMinimum()); xmaxs.append(ext.xMaximum())
            ymins.append(ext.yMinimum()); ymaxs.append(ext.yMaximum())
        return Extent(min(xmins), min(ymins), max(xmaxs), max(ymaxs))

    def _read_and_render(self):
        if self.list_layers.count() == 0: return
        self._set_status("Reading data for all layers… please wait.", "loading")
        self.btn_read.setEnabled(False); self.repaint()
        try:
            self._map_cache.clear()
            # Fixed up front, before any layer is read, so every raster AND
            # vector layer below reprojects into the *same* target — not
            # whichever CRS happened to belong to the first layer processed.
            self._cached_crs = self._resolve_target_crs()
            dst_qgs_crs = None
            if self._cached_crs:
                try:
                    dst_qgs_crs = QgsCoordinateReferenceSystem(self._cached_crs)
                    if not dst_qgs_crs.isValid(): dst_qgs_crs = None
                except Exception:
                    dst_qgs_crs = None

            nearest = self._is_discrete_mode()

            for i in range(self.list_layers.count()):
                item = self.list_layers.item(i)
                lid = item.data(Qt.UserRole)
                layer = self._layers_dict.get(lid)
                if not layer: continue

                if isinstance(layer, RasterLayer):
                    if self.rb_single.isChecked():
                        arr, ext = self._read_band(layer, self.sp_band.value(), self.sp_maxpx.value(),
                                                     dst_crs=self._cached_crs, nearest=nearest)
                        self._map_cache[lid] = ("raster_single", arr, ext)
                    else:
                        # RGB composites are always continuous imagery —
                        # bilinear resampling on reprojection, never nearest.
                        r, ext = self._read_band(layer, self.sp_r.value(), self.sp_maxpx.value(),
                                                   dst_crs=self._cached_crs)
                        g, _ = self._read_band(layer, self.sp_g.value(), self.sp_maxpx.value(),
                                                 dst_crs=self._cached_crs)
                        b, _ = self._read_band(layer, self.sp_b.value(), self.sp_maxpx.value(),
                                                 dst_crs=self._cached_crs)
                        self._map_cache[lid] = ("raster_rgb", (r, g, b), ext)

                elif isinstance(layer, VectorLayer):
                    qext = layer.extent()
                    if dst_qgs_crs is not None:
                        ct = make_coordinate_transform(layer.crs(), dst_qgs_crs)
                        if ct is not None:
                            try:
                                qext = ct.transformBoundingBox(qext)
                            except Exception as exc:
                                raise RuntimeError(
                                    f"Could not reproject vector layer '{layer.name()}' "
                                    f"extent to {self._cached_crs}: {exc}"
                                ) from exc
                    ext = Extent(qext.xMinimum(), qext.yMinimum(), qext.xMaximum(), qext.yMaximum())
                    self._map_cache[lid] = ("vector", None, ext)

            if self._cached_ext is None:
                self._cached_ext = self._compute_full_extent()
            self._set_status("Data ready. You can rearrange layers and it will update real-time.", "ready")
        except Exception as e: 
            self._set_status(f"Error: {e}", "error")
        finally: 
            self.btn_read.setEnabled(True)
            self._trigger_live_update()

    def _trigger_live_update(self):
        if self._is_updating: return
        if not self._map_cache: return
        self._update_timer.start()  # (re)start the debounce window

    def _apply_stretch(self, arr):
        valid = arr[np.isfinite(arr)]
        if len(valid) == 0: return 0.0, 1.0
        mode = self.cb_stretch.currentText()
        if mode == "Actual Min-Max": vmin, vmax = float(valid.min()), float(valid.max())
        elif "Percentile" in mode: vmin, vmax = float(np.percentile(valid, self.sp_pmin.value())), float(np.percentile(valid, self.sp_pmax.value()))
        else:
            try: vmin, vmax = float(self.le_vmin.text()), float(self.le_vmax.text())
            except ValueError: vmin, vmax = float(valid.min()), float(valid.max())
        if np.isclose(vmin, vmax): vmax = vmin + 1
        return vmin, vmax

    def _make_lon_formatter(self, format_text, dec):
        def formatter(x, pos):
            if "Default" in format_text: return f"{x:.{dec}f}"
            val = abs(x); d_lbl = "E" if x >= 0 else "W"
            if "DMS" in format_text:
                d = int(val); m = int((val - d) * 60); s = (val - d - m / 60.0) * 3600
                return f"{d}°{m}'{s:.1f}\" {d_lbl}"
            if "DM" in format_text:
                d = int(val); m = (val - d) * 60
                return f"{d}°{m:.{dec}f}' {d_lbl}"
            return f"{val:.{dec}f}° {d_lbl}"
        return formatter

    def _make_lat_formatter(self, format_text, dec):
        def formatter(y, pos):
            if "Default" in format_text: return f"{y:.{dec}f}"
            val = abs(y); d_lbl = "N" if y >= 0 else "S"
            if "DMS" in format_text:
                d = int(val); m = int((val - d) * 60); s = (val - d - m / 60.0) * 3600
                return f"{d}°{m}'{s:.1f}\" {d_lbl}"
            if "DM" in format_text:
                d = int(val); m = (val - d) * 60
                return f"{d}°{m:.{dec}f}' {d_lbl}"
            return f"{val:.{dec}f}° {d_lbl}"
        return formatter

    def _style_axes(self, ax, txt_col, font_fam, fig_bg):
        coord_size = self.sp_coord_size.value()
        ax.tick_params(colors=txt_col, labelsize=coord_size)
        ax.xaxis.set_major_locator(mticker.MaxNLocator(nbins=self.sp_xtick_count.value()))
        ax.yaxis.set_major_locator(mticker.MaxNLocator(nbins=self.sp_ytick_count.value()))
        fmt = self.cb_coord_format.currentText()
        dec = self.sp_coord_decimals.value()

        if "Default" not in fmt:
            ax.xaxis.set_major_formatter(mticker.FuncFormatter(self._make_lon_formatter(fmt, dec)))
            ax.yaxis.set_major_formatter(mticker.FuncFormatter(self._make_lat_formatter(fmt, dec)))
        else:
            ax.xaxis.set_major_formatter(mticker.FormatStrFormatter(f"%.{dec}f"))
            ax.yaxis.set_major_formatter(mticker.FormatStrFormatter(f"%.{dec}f"))

        x_rot = self.sp_xlabel_rotation.value()
        y_rot = self.sp_ylabel_rotation.value()
        x_ha = "right" if 10 < x_rot < 350 else "center"

        for tick in ax.get_xticklabels():
            tick.set_fontfamily(font_fam); tick.set_rotation(x_rot); tick.set_ha(x_ha)
        for tick in ax.get_yticklabels():
            tick.set_fontfamily(font_fam); tick.set_rotation(y_rot); tick.set_ha("right")
        for sp_item in ax.spines.values(): sp_item.set_color(txt_col)
        if self.chk_grid.isChecked():
            ls = ("--" if "Dashed" in self.cb_grid_style.currentText() else ":" if "Dotted" in self.cb_grid_style.currentText() else "-")
            ax.grid(True, color=txt_col, linestyle=ls, linewidth=0.4, alpha=0.5)

        axislbl_style = _style_kwargs(self.chk_axislbl_bold.isChecked(), self.chk_axislbl_italic.isChecked())
        xlabel_text = self.le_xaxis_label.text()
        ylabel_text = self.le_yaxis_label.text()
        if xlabel_text:
            ax.set_xlabel(xlabel_text, color=txt_col, fontfamily=font_fam, fontsize=coord_size + 1, **axislbl_style)
        if ylabel_text:
            ax.set_ylabel(ylabel_text, color=txt_col, fontfamily=font_fam, fontsize=coord_size + 1, **axislbl_style)

    def _get_theme(self, bg_text):
        if "Soft Black" in bg_text: return "#2b2b2b", "#2b2b2b", "#e2e8f0"
        if "White" in bg_text: return "white", "white", "black"
        if "Dark Text" in bg_text: return "none", "none", "black"
        return "none", "none", "white"

    def _get_basemap_image(self, ax, provider, crs):
        """Return (image_array, extent) for the current view, reusing the
        last render when the provider/CRS/view bounds are unchanged.

        The actual fetch/stitch/reprojection is done by basemap_io using
        QGIS's own map-render pipeline (see render_basemap_to_array) — this
        just does that work once per unique (provider, crs, bounds) and
        replays the resulting image array on every subsequent re-render
        that doesn't actually change the view. That turns "any control
        tweak re-renders the whole basemap" into "only an actual
        pan/zoom/provider change does".
        """
        key = (
            provider.get("url", "") if isinstance(provider, dict) else repr(provider)[:80],
            str(crs),
            tuple(round(v, 6) for v in ax.get_xlim()),
            tuple(round(v, 6) for v in ax.get_ylim()),
        )
        cached = self._basemap_cache.get(key)
        if cached is not None:
            return cached

        canvas_w = max(1, self.canvas_map.width())
        canvas_h = max(1, self.canvas_map.height())
        out_w = max(1, int(canvas_w * self.sp_map_w.value()))
        out_h = max(1, int(canvas_h * self.sp_map_h.value()))

        xmin, xmax = ax.get_xlim()
        ymin, ymax = ax.get_ylim()
        result = render_basemap_to_array(
            provider["url"], provider.get("zmax", 19), crs,
            (xmin, xmax, ymin, ymax), out_w, out_h,
        )

        self._basemap_cache[key] = result
        if len(self._basemap_cache) > 6:
            self._basemap_cache.pop(next(iter(self._basemap_cache)))
        return result

    def _live_update(self):
        self.fig_map.clf()
        if not self._cached_ext: return

        fig_bg, ax_bg, txt_col = self._get_theme(self.cb_bg_color.currentText())
        font_fam = self.cb_font_family.currentText()
        basemap_choice = self.cb_basemap.currentText()

        self.fig_map.patch.set_facecolor(fig_bg)
        ax = self.fig_map.add_axes([self.sp_map_x.value(), self.sp_map_y.value(), self.sp_map_w.value(), self.sp_map_h.value()])
        
        if basemap_choice != "None": ax.set_facecolor("none")
        elif ax_bg != "none": ax.set_facecolor(ax_bg)

        view_ext = self._view_ext if self._view_ext is not None else self._cached_ext
        ax.set_xlim(view_ext.xMinimum(), view_ext.xMaximum())
        ax.set_ylim(view_ext.yMinimum(), view_ext.yMaximum())

        title = self.le_title.text()
        subtitle = self.le_subtitle.text()
        title_style = _style_kwargs(self.chk_title_bold.isChecked(), self.chk_title_italic.isChecked())
        subtitle_style = _style_kwargs(self.chk_subtitle_bold.isChecked(), self.chk_subtitle_italic.isChecked())
        align = self.cb_title_align.currentText()

        if title: ax.set_title(title, loc=align, color=txt_col, fontfamily=font_fam, fontsize=self.sp_title_size.value(), pad=20 if subtitle else 10, **title_style)
        if subtitle: 
            x_pos = 0.5 if align == 'center' else (0.0 if align == 'left' else 1.0)
            ax.text(x_pos, 1.02, subtitle, ha=align, va='bottom', transform=ax.transAxes, color=txt_col, fontfamily=font_fam, fontsize=self.sp_sub_size.value(), **subtitle_style)

        if not self.chk_axes.isChecked(): ax.axis("off")
        else: self._style_axes(ax, txt_col, font_fam, fig_bg)

        raster_alpha = self.sp_raster_alpha.value()
        self._colorbar_drawn = False

        for i in range(self.list_layers.count() - 1, -1, -1):
            item = self.list_layers.item(i)
            if item.checkState() != Qt.Checked: continue
            
            lid = item.data(Qt.UserRole)
            if lid not in self._map_cache: continue
            
            ltype, data, ext = self._map_cache[lid]
            plot_ext = [ext.xMinimum(), ext.xMaximum(), ext.yMinimum(), ext.yMaximum()]

            if ltype == "raster_single":
                self._cached_arr = data
                if self._is_discrete_mode():
                    self._render_discrete(ax, ax_bg, txt_col, font_fam, plot_ext, raster_alpha)
                else:
                    self._render_continuous(ax, ax_bg, txt_col, font_fam, plot_ext, raster_alpha)
            elif ltype == "raster_rgb":
                self._cached_rgb = data
                self._render_rgb(ax, plot_ext, raster_alpha)
            elif ltype == "vector":
                vlyr = self._layers_dict.get(lid)
                if vlyr is None or not vlyr.isValid(): continue
                dst_crs = None
                if self._cached_crs:
                    try:
                        dst_crs = QgsCoordinateReferenceSystem(self._cached_crs)
                    except Exception:
                        dst_crs = None
                # Only fetch/draw what's inside the current view, and let
                # QGIS generalize complex geometries (e.g. a nationwide
                # coastline layer) to roughly one vertex per screen pixel —
                # keeps large vector files smooth instead of redrawing
                # every vertex of every feature on every re-render.
                filter_rect = QgsRectangle(view_ext.xMinimum(), view_ext.yMinimum(),
                                            view_ext.xMaximum(), view_ext.yMaximum())
                canvas_px = max(1, self.canvas_map.width())
                simplify_tol = (view_ext.xMaximum() - view_ext.xMinimum()) / canvas_px
                fallback = "#ff3333" if txt_col == "#e2e8f0" else "#ff0000"
                render_vector_layer(ax, vlyr, dst_crs=dst_crs, extent=filter_rect,
                                     simplify_tolerance=simplify_tol,
                                     layer_alpha=raster_alpha, fallback_color=fallback)

        if basemap_choice != "None" and self._cached_crs is not None:
            provider = self.basemap_dict.get(basemap_choice)
            if provider is not None:
                try:
                    img, img_ext = self._get_basemap_image(ax, provider, self._cached_crs)
                    ax.imshow(img, extent=img_ext, interpolation="bilinear", zorder=-1)
                    if self.chk_show_attrib.isChecked():
                        attrib_text = provider.get("attribution", "")
                        if attrib_text:
                            ax.text(0.99, 0.01, attrib_text, transform=ax.transAxes,
                                    fontsize=self.sp_attrib_size.value(), ha="right", va="bottom",
                                    color="black", zorder=1000,
                                    bbox=dict(boxstyle="square,pad=0.15", fc="white", ec="none", alpha=0.6))
                except Exception as e:
                    print(f"Failed to load basemap: {e}")

        if self.chk_north_arrow.isChecked():
            self._render_north_arrow(ax, txt_col)

        if self.chk_scalebar.isChecked():
            self._render_scalebar(ax, view_ext, txt_col, font_fam)

        self.canvas_map.draw()

    def _render_north_arrow(self, ax, txt_col):
        x = self.sp_north_x.value()
        y = self.sp_north_y.value()
        size = self.sp_north_size.value()
        style = self.cb_north_style.currentText()
        bg_col = "#ffffff" if txt_col != "#ffffff" else "#2b2b2b"

        try:
            if style in ["Classic Triangle", "Sleek Needle"]:
                width = size * 0.4
                if style == "Classic Triangle":
                    left_poly = [[x, y+size], [x-width/2, y], [x, y]]
                    right_poly = [[x, y+size], [x, y], [x+width/2, y]]
                else:
                    bottom_mid = y + size * 0.25
                    left_poly = [[x, y+size], [x-width/2, y], [x, bottom_mid]]
                    right_poly = [[x, y+size], [x, bottom_mid], [x+width/2, y]]

                ax.add_patch(mpatches.Polygon(left_poly, closed=True, facecolor=txt_col, edgecolor=txt_col, lw=1, transform=ax.transAxes, clip_on=False))
                ax.add_patch(mpatches.Polygon(right_poly, closed=True, facecolor=bg_col, edgecolor=txt_col, lw=1, transform=ax.transAxes, clip_on=False))
                ax.text(x, y + size * 1.1, "N", transform=ax.transAxes, ha="center", va="bottom", color=txt_col, fontsize=max(10, int(size * 100)), fontweight="bold", clip_on=False)
                
            elif style == "Compass Rose (N-S-E-W)":
                for lbl, dx, dy in [("N", 0, size), ("S", 0, -size), ("E", size, 0), ("W", -size, 0)]:
                    ax.annotate("", xy=(x + dx, y + dy), xytext=(x, y), xycoords="axes fraction", textcoords="axes fraction", arrowprops=dict(arrowstyle="-|>", color=txt_col, lw=1.5, mutation_scale=14), annotation_clip=False)
                ax.text(x, y + size * 1.18, "N", transform=ax.transAxes, ha="center", va="bottom", color=txt_col, fontsize=max(10, int(size * 90)), fontweight="bold", clip_on=False)
            else:
                lw = 3 if style == "Fancy Arrow" else 2
                scale = 26 if style == "Fancy Arrow" else 20
                arrowstyle = "fancy" if style == "Fancy Arrow" else "-|>"
                ax.annotate("", xy=(x, y), xytext=(x, y - size), xycoords="axes fraction", textcoords="axes fraction", arrowprops=dict(arrowstyle=arrowstyle, color=txt_col, lw=lw, mutation_scale=scale, facecolor=txt_col), annotation_clip=False)
                ax.text(x, y + size * 0.15, "N", transform=ax.transAxes, ha="center", va="bottom", color=txt_col, fontsize=max(10, int(size * 100)), fontweight="bold", clip_on=False)
        except Exception as e:
            print(f"Failed to draw north arrow: {e}")

    def _render_scalebar(self, ax, view_ext, txt_col, font_fam):
        try:
            is_geographic = True
            if self._cached_crs:
                crs_str = str(self._cached_crs)
                if any(tag in crs_str for tag in ["UTM", "utm", "3857", "3395", "metre", "meter"]):
                    is_geographic = False
                try:
                    import pyproj
                    crs_obj = pyproj.CRS(self._cached_crs)
                    is_geographic = crs_obj.is_geographic
                except Exception as exc:
                    # pyproj is optional (not one of RasterViz's required
                    # dependencies) — if it's missing or the CRS string
                    # can't be parsed, the tag-based `is_geographic` guess
                    # above stays in effect. Log so a genuinely broken CRS
                    # string isn't silently hidden.
                    QgsMessageLog.logMessage(f"RasterViz: pyproj CRS check skipped: {exc}", "RasterViz", Qgis.Info)

            unit_choice = self.cb_scalebar_unit.currentText()
            length_val = self.sp_scalebar_length.value()
            orient = self.cb_scalebar_orient.currentText()
            style = self.cb_scalebar_style.currentText()
            n_segments = self.sp_scalebar_segments.value()
            is_vertical = orient == "Vertical"

            if unit_choice == "km": target_m = length_val * 1000.0
            else: target_m = length_val

            x0 = self.sp_scalebar_x.value()
            y0 = self.sp_scalebar_y.value()

            xlim = ax.get_xlim(); ylim = ax.get_ylim()
            data_x0 = xlim[0] + x0 * (xlim[1] - xlim[0])
            data_y0 = ylim[0] + y0 * (ylim[1] - ylim[0])

            if is_geographic:
                lo, hi = data_x0, data_x0 + 10.0
                for _ in range(40):
                    mid = (lo + hi) / 2
                    d = _haversine_m(data_x0, data_y0, mid, data_y0)
                    if d < target_m: lo = mid
                    else: hi = mid
                data_x1 = hi
            else:
                data_x1 = data_x0 + target_m

            bar_frac = (data_x1 - data_x0) / (xlim[1] - xlim[0]) if (xlim[1] - xlim[0]) != 0 else 0.1

            display_unit = unit_choice
            display_len = length_val
            if unit_choice == "Auto":
                if target_m >= 1000: display_unit, display_len = "km", target_m / 1000.0
                else: display_unit, display_len = "m", target_m

            def frac_point(along, across):
                return (x0 + across, y0 + along) if is_vertical else (x0 + along, y0 + across)

            bar_thickness = 0.012
            bg_col = "#ffffff" if txt_col != "#ffffff" else "#2b2b2b"

            if "Box" in style or "Alternating" in style:
                is_double = "Double" in style
                h = bar_thickness / 2 if is_double else bar_thickness
                for i in range(n_segments):
                    seg_lo = bar_frac * i / n_segments
                    seg_w = bar_frac / n_segments
                    
                    face1 = txt_col if i % 2 == 0 else bg_col
                    p0 = frac_point(seg_lo, 0)
                    if is_vertical:
                        rect1 = mpatches.Rectangle((p0[0] - h, p0[1]), h, seg_w, transform=ax.transAxes, facecolor=face1, edgecolor=txt_col, lw=0.8, clip_on=False)
                    else:
                        rect1 = mpatches.Rectangle((p0[0], p0[1] - h), seg_w, h, transform=ax.transAxes, facecolor=face1, edgecolor=txt_col, lw=0.8, clip_on=False)
                    ax.add_patch(rect1)

                    if is_double:
                        face2 = bg_col if i % 2 == 0 else txt_col
                        if is_vertical: rect2 = mpatches.Rectangle((p0[0], p0[1]), h, seg_w, transform=ax.transAxes, facecolor=face2, edgecolor=txt_col, lw=0.8, clip_on=False)
                        else: rect2 = mpatches.Rectangle((p0[0], p0[1]), seg_w, h, transform=ax.transAxes, facecolor=face2, edgecolor=txt_col, lw=0.8, clip_on=False)
                        ax.add_patch(rect2)
                        
            elif style == "Stepped Line":
                p_start = frac_point(0, 0); p_end = frac_point(bar_frac, 0)
                ax.plot([p_start[0], p_end[0]], [p_start[1], p_end[1]], transform=ax.transAxes, color=txt_col, lw=1.5, clip_on=False)
                for i in range(n_segments + 1):
                    seg_loc = bar_frac * i / n_segments
                    pa = frac_point(seg_loc, 0); pb = frac_point(seg_loc, 0.015)
                    ax.plot([pa[0], pb[0]], [pa[1], pb[1]], transform=ax.transAxes, color=txt_col, lw=1.5, clip_on=False)

            else: 
                p_start = frac_point(0, 0); p_end = frac_point(bar_frac, 0)
                ax.plot([p_start[0], p_end[0]], [p_start[1], p_end[1]], transform=ax.transAxes, color=txt_col, lw=2, clip_on=False)
                for along in (0, bar_frac):
                    pa = frac_point(along, -0.008); pb = frac_point(along, 0.008)
                    ax.plot([pa[0], pb[0]], [pa[1], pb[1]], transform=ax.transAxes, color=txt_col, lw=2, clip_on=False)

            lbl_across = 0.02 if ("Box" not in style or "Double" not in style) else 0.025
            
            for i in range(n_segments + 1):
                current_val = (display_len * i) / n_segments
                seg_frac = (bar_frac * i) / n_segments
                val_str = f"{current_val:g}"
                if i == n_segments: val_str = f"{val_str} {display_unit}"
                
                tx, ty = frac_point(seg_frac, lbl_across)
                if is_vertical:
                    ax.text(tx, ty, val_str, transform=ax.transAxes, ha="left", va="center", rotation=90, color=txt_col, fontsize=8, fontfamily=font_fam, fontweight="bold", clip_on=False)
                else:
                    ax.text(tx, ty, val_str, transform=ax.transAxes, ha="center", va="bottom", color=txt_col, fontsize=8, fontfamily=font_fam, fontweight="bold", clip_on=False)
                            
        except Exception as e:
            print(f"Failed to draw scale bar: {e}")

    def _render_discrete(self, ax, ax_bg, txt_col, font_fam, plot_ext, raster_alpha):
        arr = self._cached_arr
        if len(self._discrete_rows) == 0: return
        rows = self._discrete_rows
        height, width = arr.shape
        rgba = np.zeros((height, width, 4), dtype=np.uint8)
        nodata_qcol = QColor(self._nodata_color)
        if nodata_qcol.isValid() and nodata_qcol.alpha() > 0: nd_rgba = np.array([nodata_qcol.red(), nodata_qcol.green(), nodata_qcol.blue(), nodata_qcol.alpha()], dtype=np.uint8)
        else: nd_rgba = np.array([0, 0, 0, 0], dtype=np.uint8)
        rgba[~np.isfinite(arr)] = nd_rgba

        for row_w in rows:
            gc = row_w.gridcode; qc = QColor(row_w.get_color())
            if not qc.isValid(): qc = QColor("#888888")
            mask = np.isfinite(arr) & np.isclose(arr, gc, rtol=0, atol=0.5)
            rgba[mask] = [qc.red(), qc.green(), qc.blue(), 255]

        ax.imshow(rgba, extent=plot_ext, interpolation="nearest", aspect="equal", origin="upper", alpha=raster_alpha)

        if self.chk_legend.isChecked() and self.chk_disc_legend.isChecked() and not self._colorbar_drawn:
            self._colorbar_drawn = True
            patches = []
            for row_w in rows:
                dec = row_w.get_decimals(); gc = row_w.gridcode
                gc_str = str(int(gc)) if (float(gc).is_integer() and dec == 0) else f"{gc:.{dec}f}"
                lbl = row_w.get_label()
                display_lbl = f"{lbl}  ({gc_str})" if lbl != gc_str else lbl
                patches.append(mpatches.Patch(facecolor=row_w.get_color(), edgecolor=txt_col, linewidth=0.6, label=display_lbl))
            ncol = max(1, (len(patches) + 11) // 12)
            leg = self.fig_map.legend(handles=patches, loc="lower left", bbox_to_anchor=(self.sp_leg_x.value(), self.sp_leg_y.value()), bbox_transform=self.fig_map.transFigure, framealpha=0.85, facecolor=ax_bg if ax_bg != "none" else "#2b2b2b", edgecolor=txt_col, fontsize=self.sp_leg_tick_size.value(), title=self.le_cbar_label.text(), title_fontsize=self.sp_leg_lbl_size.value(), ncol=ncol)
            lbl_style = _style_kwargs(self.chk_cbar_lbl_bold.isChecked(), self.chk_cbar_lbl_italic.isChecked())
            tick_style = _style_kwargs(self.chk_cbar_tick_bold.isChecked(), self.chk_cbar_tick_italic.isChecked())
            leg.get_title().set_color(txt_col); leg.get_title().set_fontfamily(font_fam)
            leg.get_title().set_fontweight(lbl_style["fontweight"]); leg.get_title().set_fontstyle(lbl_style["fontstyle"])
            for text in leg.get_texts():
                text.set_color(txt_col); text.set_fontfamily(font_fam)
                text.set_fontweight(tick_style["fontweight"]); text.set_fontstyle(tick_style["fontstyle"])

    def _render_continuous(self, ax, ax_bg, txt_col, font_fam, plot_ext, raster_alpha, cmap_override=None, vmin_override=None, vmax_override=None):
        arr = self._cached_arr
        valid_data = arr[np.isfinite(arr)]
        vmin, vmax = (vmin_override, vmax_override) if vmin_override is not None else self._apply_stretch(arr)
        actual_min = float(valid_data.min()) if len(valid_data) > 0 else vmin
        actual_max = float(valid_data.max()) if len(valid_data) > 0 else vmax

        cmap_name = cmap_override if cmap_override else COLORMAPS[self.cmap_idx]
        try:
            cmap = matplotlib.colormaps[cmap_name].copy()
            if not cmap_override and self.chk_reverse_cmap.isChecked():
                cmap = cmap.reversed()
        except Exception:
            cmap = matplotlib.colormaps["viridis"].copy()
            
        if self.chk_nodata_transp.isChecked(): cmap.set_bad(alpha=0)

        im = ax.imshow(arr, cmap=cmap, vmin=vmin, vmax=vmax, extent=plot_ext, interpolation="bilinear", aspect="equal", origin="upper", alpha=raster_alpha)

        if self.chk_legend.isChecked() and not self._colorbar_drawn:
            self._colorbar_drawn = True
            is_vert = self.cb_orient.currentText() == "vertical"
            cax_w = self.sp_leg_h.value() if is_vert else self.sp_leg_w.value()
            cax_h = self.sp_leg_w.value() if is_vert else self.sp_leg_h.value()

            cax = self.fig_map.add_axes([self.sp_leg_x.value(), self.sp_leg_y.value(), cax_w, cax_h])
            extend_opt = self.cb_legend_style.currentText()
            extend_str = ("both" if "Both" in extend_opt else "max" if "Right" in extend_opt else "min" if "Left" in extend_opt else "neither")
                          
            cb = self.fig_map.colorbar(im, cax=cax, orientation=self.cb_orient.currentText(), extend=extend_str, extendfrac=0.04, drawedges=False)
            
            lbl_text = self.le_cbar_label.text()
            lbl_style = _style_kwargs(self.chk_cbar_lbl_bold.isChecked(), self.chk_cbar_lbl_italic.isChecked())
            tick_style = _style_kwargs(self.chk_cbar_tick_bold.isChecked(), self.chk_cbar_tick_italic.isChecked())
            lbl_pos = self.cb_cbar_lbl_pos.currentText()

            cb.set_label(lbl_text, color=txt_col, fontfamily=font_fam, fontsize=self.sp_leg_lbl_size.value(), labelpad=self.sp_leg_pad_label.value(), **lbl_style)
            
            if is_vert:
                if lbl_pos == "Top":
                    cb.set_label("")
                    cb.ax.set_title(lbl_text, color=txt_col, fontfamily=font_fam, fontsize=self.sp_leg_lbl_size.value(), pad=self.sp_leg_pad_label.value(), **lbl_style)
                elif lbl_pos == "Left": cb.ax.yaxis.set_label_position("left")
                elif lbl_pos == "Right": cb.ax.yaxis.set_label_position("right")
            else:
                if lbl_pos == "Top": cb.ax.xaxis.set_label_position("top")
                elif lbl_pos == "Bottom": cb.ax.xaxis.set_label_position("bottom")
                elif lbl_pos == "Right":
                    cb.set_label("")
                    cb.ax.text(1.02, 0.5, lbl_text, transform=cb.ax.transAxes, va='center', ha='left', color=txt_col, fontfamily=font_fam, fontsize=self.sp_leg_lbl_size.value(), **lbl_style)
                elif lbl_pos == "Left":
                    cb.set_label("")
                    cb.ax.text(-0.02, 0.5, lbl_text, transform=cb.ax.transAxes, va='center', ha='right', color=txt_col, fontfamily=font_fam, fontsize=self.sp_leg_lbl_size.value(), **lbl_style)

            cb.ax.tick_params(colors=txt_col, labelsize=self.sp_leg_tick_size.value(), pad=self.sp_leg_pad_tick.value())
            for tick in cb.ax.get_xticklabels() + cb.ax.get_yticklabels():
                tick.set_fontfamily(font_fam); tick.set_fontweight(tick_style["fontweight"]); tick.set_fontstyle(tick_style["fontstyle"])

            dec = self.sp_cbar_decimals.value(); tc = self.sp_tick_count.value()
            if self.chk_ticks.isChecked(): cb.locator = mticker.MaxNLocator(nbins=tc, prune="both"); cb.update_ticks()
            else:
                ticks_pos = np.linspace(vmin, vmax, tc); cb.set_ticks(ticks_pos)
                if tc == 2: cb.set_ticklabels([f"{actual_min:.{dec}f}", f"{actual_max:.{dec}f}"])
                else:
                    lbls = [f"{actual_min:.{dec}f}"]
                    lbls.extend([f"{t:.{dec}f}" for t in ticks_pos[1:-1]])
                    lbls.append(f"{actual_max:.{dec}f}")
                    cb.set_ticklabels(lbls)
            cb.outline.set_edgecolor(txt_col); cb.outline.set_linewidth(0.8)

    def _render_rgb(self, ax, plot_ext, raster_alpha):
        def norm(a):
            v0, v1 = self._apply_stretch(a)
            a_c = np.clip(a, v0, v1)
            return (a_c - v0) / (v1 - v0 + 1e-12)
        rgb = np.dstack([norm(self._cached_rgb[0]), norm(self._cached_rgb[1]), norm(self._cached_rgb[2])])
        ax.imshow(rgb, extent=plot_ext, interpolation="bilinear", aspect="equal", origin="upper", alpha=raster_alpha)

    def export_figure(self):
        if self._update_timer.isActive():
            self._update_timer.stop()
            self._live_update()
        path, _ = QFileDialog.getSaveFileName(self, "Save Image", "", "PNG (*.png);;SVG (*.svg);;TIFF (*.tif);;PDF (*.pdf)")
        if not path: return
        is_raster = path.lower().endswith((".png", ".tif"))
        dpi = self.sp_canvas_dpi.value() if is_raster else min(300, self.sp_canvas_dpi.value())
        transparent = ("Transparent" in self.cb_bg_color.currentText())
        facecolor = self.fig_map.get_facecolor()

        if self._canvas_fixed_size_in:
            # A fixed paper size (A4, A3, ...) is active: export at the
            # exact physical size instead of cropping tight to content, so
            # the output really is that paper size at the chosen DPI.
            w_in, h_in = self._canvas_fixed_size_in
            self.fig_map.set_size_inches(w_in, h_in)
            self.fig_map.savefig(path, dpi=dpi, facecolor=facecolor, transparent=transparent)
        else:
            self.fig_map.savefig(path, dpi=dpi, bbox_inches="tight", facecolor=facecolor, transparent=transparent)
        self._set_status(f"Exported: {path}", "ready")
        QMessageBox.information(self, "Success", f"Image saved:\n{path}")