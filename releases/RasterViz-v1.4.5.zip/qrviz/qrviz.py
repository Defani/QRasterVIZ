"""
RasterViz Plugin for QGIS
Provides publication-quality raster rendering styled after rasterio.show(),
with full GUI controls for colormaps, stretch, coordinate labels, grid,
colorbar orientation, label rotation, multi-map layout series, vector
overlays, and web basemaps.

Raster and vector reading, and the web basemap layer, are all 100%
QGIS-native (no rasterio/geopandas/fiona/contextily needed). RasterViz has
zero third-party Python dependencies.

License: GNU GPL v2 or later
Repository: https://github.com/Defani/QRasterVIZ
"""

import os
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.PyQt.QtGui import QIcon


class QRVIZPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        self.action = QAction(icon, "RasterViz", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToRasterMenu("&RasterViz", self.action)

    def unload(self):
        self.iface.removeToolBarIcon(self.action)
        self.iface.removePluginRasterMenu("&RasterViz", self.action)
        del self.action

    def run(self):
        try:
            from .dialog import QRVIZDialog
        except Exception as exc:
            QMessageBox.critical(
                self.iface.mainWindow(),
                "RasterViz — failed to start",
                "RasterViz could not start because of an unexpected error "
                "in this QGIS installation:\n\n{}\n\n"
                "Try reinstalling the plugin.".format(exc),
            )
            return

        if self.dialog is None:
            self.dialog = QRVIZDialog(parent=self.iface.mainWindow())

        self.dialog.populate_layers()
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
