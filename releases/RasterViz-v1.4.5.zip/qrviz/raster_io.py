"""
raster_io.py — QGIS-native raster I/O layer for RasterViz.

This used to be backed by rasterio. It is now backed entirely by QGIS's own
API (QgsRasterLayer + QgsRasterDataProvider.block()), which is bundled with
every QGIS installation and reads the same GDAL formats rasterio does
(GeoTIFF, IMG, VRT, NetCDF, HDF, ...). No third-party package is required
for raster support any more.

The public interface (RasterLayer.isValid/id/name/bandCount/width/height/
extent/crs/read_band, plus RASTER_REGISTRY and SUPPORTED_RASTER_FILTER) is
unchanged, so dialog.py does not need to know the backend changed.

Cross-CRS reprojection: `read_band()` optionally takes a `dst_crs` (target
CRS, same shared CRS dialog.py resolves once per render session and also
hands to `render_vector_layer()` for vector layers — see `_cached_crs` in
dialog.py). When `dst_crs` differs from the raster's native CRS, the block
is read through `QgsRasterProjector` on top of `QgsCoordinateTransform`
instead of the provider directly, and the *transformed* extent is returned
so callers never have to reconcile mixed-CRS extents themselves. This stays
100% QGIS-native — no rasterio/gdal.Warp/pyproj added.
"""

import os
import uuid
import numpy as np

from qgis.core import (
    QgsRasterLayer, Qgis, QgsMessageLog,
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject,
    QgsRasterProjector, QgsRasterDataProvider, QgsCsException,
)


class Extent:
    """Minimal stand-in for qgis.core.QgsRectangle (read-only bounds)."""
    __slots__ = ("_xmin", "_ymin", "_xmax", "_ymax")

    def __init__(self, xmin, ymin, xmax, ymax):
        self._xmin, self._ymin, self._xmax, self._ymax = xmin, ymin, xmax, ymax

    def xMinimum(self): return self._xmin
    def xMaximum(self): return self._xmax
    def yMinimum(self): return self._ymin
    def yMaximum(self): return self._ymax


# Qgis.DataType (raster block sample type) -> numpy dtype, for the fast
# buffer-decoding path in read_band(). Complex types are intentionally left
# out; they fall back to the value-by-value path below, since none of
# RasterViz's rendering modes (single-band, discrete, RGB) use complex data.
#
# QGIS >=3.36 exposes these as Qgis.DataType.Byte (a proper Python enum);
# older 3.x releases only have the flat Qgis.Byte constants. Both spellings
# are tried so this works across the whole 3.0-3.99 range declared in
# metadata.txt.
def _dtype_enum(name):
    dt = getattr(Qgis, "DataType", None)
    if dt is not None and hasattr(dt, name):
        return getattr(dt, name)
    return getattr(Qgis, name, None)


_QGIS_DTYPE_TO_NUMPY = {
    v: np_t for v, np_t in (
        (_dtype_enum("Byte"), np.uint8),
        (_dtype_enum("UInt16"), np.uint16),
        (_dtype_enum("Int16"), np.int16),
        (_dtype_enum("UInt32"), np.uint32),
        (_dtype_enum("Int32"), np.int32),
        (_dtype_enum("Float32"), np.float32),
        (_dtype_enum("Float64"), np.float64),
    ) if v is not None
}


# Same cross-version-spelling problem as Qgis.DataType above:
# QgsRasterDataProvider.ResamplingMethod is a proper Python enum on newer
# QGIS, a flat set of int constants on older 3.x.
def _resampling_enum(name):
    rm = getattr(QgsRasterDataProvider, "ResamplingMethod", None)
    if rm is not None and hasattr(rm, name):
        return getattr(rm, name)
    return getattr(QgsRasterDataProvider, name, None)


class RasterLayer:
    """Minimal stand-in for qgis.core.QgsRasterLayer, backed by QGIS itself."""

    def __init__(self, path, display_name=None):
        self.path = path
        self._id = str(uuid.uuid4())
        self._name = display_name or os.path.basename(path)
        self._valid = False
        self._width = 0
        self._height = 0
        self._band_count = 0
        self._extent = None
        self._crs = None
        self._qgs_crs = None
        self._error = None
        self._qgs_layer = None

        try:
            lyr = QgsRasterLayer(path, self._name, "gdal")
            if not lyr.isValid():
                raise RuntimeError(
                    "QGIS could not open this raster with its GDAL provider "
                    f"(unsupported/corrupt format?): {path}"
                )
            self._qgs_layer = lyr
            self._width = lyr.width()
            self._height = lyr.height()
            self._band_count = lyr.bandCount()
            e = lyr.extent()
            self._extent = Extent(e.xMinimum(), e.yMinimum(), e.xMaximum(), e.yMaximum())
            self._qgs_crs = lyr.crs()
            self._crs = self._qgs_crs.authid() or None
            self._valid = True
        except Exception as exc:
            self._error = str(exc)
            self._valid = False

    def isValid(self): return self._valid
    def id(self): return self._id
    def name(self): return self._name
    def bandCount(self): return self._band_count
    def width(self): return self._width
    def height(self): return self._height
    def extent(self): return self._extent
    def crs(self): return self._crs
    def qgs_crs(self): return self._qgs_crs
    def error_message(self): return self._error

    def read_band(self, band_no, max_px_k=1000, dst_crs=None, nearest=False):
        """Read one band, resampled to at most max_px_k*1000 pixels.

        Returns (numpy_float64_array_with_nan_nodata, Extent).

        `dst_crs` is the shared target CRS for the current render session
        (a string authid or a QgsCoordinateReferenceSystem — dialog.py's
        `_cached_crs` is a string, so both are accepted). When it is None,
        invalid, or equal to this raster's native CRS, this is exactly the
        original QGIS-native path: `provider.block(band_no, extent, w, h)`
        with `provider.sourceNoDataValue`/`sourceHasNoDataValue` masking,
        and the returned extent is the raster's own native extent.

        When `dst_crs` names a *different* valid CRS, the block is instead
        read through `QgsRasterProjector` sitting on top of the provider,
        with the extent transformed via `QgsCoordinateTransform` first —
        the raster equivalent of what `render_vector_layer(dst_crs=...)`
        already does for vector layers. The returned extent is the
        *transformed* one, so `dialog.py` never has to combine/plot native
        extents from mismatched CRSs.

        `nearest`, when reprojecting, forces nearest-neighbour resampling
        instead of bilinear — required for discrete/categorical rasters
        (class codes must stay exact integers, never interpolated).
        """
        provider = self._qgs_layer.dataProvider()
        src_crs = self._qgs_crs

        dst_qgs_crs = None
        if dst_crs:
            dst_qgs_crs = (
                dst_crs if isinstance(dst_crs, QgsCoordinateReferenceSystem)
                else QgsCoordinateReferenceSystem(dst_crs)
            )
            if not dst_qgs_crs.isValid():
                # A target CRS was explicitly requested but couldn't be
                # resolved (bad/unknown authid, malformed WKT/proj string,
                # ...). Silently falling through to the native-CRS path
                # here would return this layer's data unprojected while
                # every other layer in the session *is* reprojected —
                # exactly the silent misalignment this whole reprojection
                # path exists to prevent. Fail loudly instead.
                raise RuntimeError(
                    f"Raster '{self._name}': requested target CRS "
                    f"{dst_crs!r} is not a valid/recognised CRS."
                )

        needs_reproj = bool(
            dst_qgs_crs is not None
            and src_crs is not None and src_crs.isValid()
            and dst_qgs_crs != src_crs
        )

        max_px = max_px_k * 1000
        total_px = self._width * self._height
        out_w, out_h = self._width, self._height
        if total_px > max_px and total_px > 0:
            scale = (max_px / total_px) ** 0.5
            out_w = max(1, int(self._width * scale))
            out_h = max(1, int(self._height * scale))

        if not needs_reproj:
            qgs_extent = self._qgs_layer.extent()
            block = provider.block(band_no, qgs_extent, out_w, out_h)
            arr = self._decode_block(block, provider, band_no, out_w, out_h)
            return arr, self._extent

        # -- reprojected path: QgsRasterProjector + QgsCoordinateTransform --
        try:
            transform = QgsCoordinateTransform(src_crs, dst_qgs_crs, QgsProject.instance())
            dst_extent_qgs = transform.transformBoundingBox(self._qgs_layer.extent())
        except QgsCsException as exc:
            # No silent fallback to native/misaligned data: surface a clear
            # error so dialog.py's existing `_set_status(..., "error")` path
            # (in `_read_and_render`) tells the user this layer's overlay
            # could be wrong, instead of quietly drawing it anyway.
            raise RuntimeError(
                f"Could not reproject raster '{self._name}' from "
                f"{src_crs.authid() or src_crs.toProj()} to "
                f"{dst_qgs_crs.authid() or dst_qgs_crs.toProj()}: {exc}"
            ) from exc

        # Resampling used while *sampling the source* for the reprojected
        # grid: nearest for discrete/categorical rasters (class codes must
        # never come out as interpolated fractions), bilinear otherwise.
        method = _resampling_enum("Nearest" if nearest else "Bilinear")
        if method is not None:
            try:
                provider.setZoomedInResamplingMethod(method)
                provider.setZoomedOutResamplingMethod(method)
            except Exception as exc:
                # Older/other provider without these setters — the
                # reprojected block is still readable, just without this
                # resampling-method override, so this is non-fatal.
                QgsMessageLog.logMessage(f"RasterViz: resampling method not set: {exc}", "RasterViz", Qgis.Info)

        projector = QgsRasterProjector()
        projector.setInput(provider)
        try:
            projector.setCrs(src_crs, dst_qgs_crs, QgsProject.instance().transformContext())
        except TypeError:
            # Older QGIS API: setCrs(srcCRS, destCRS) with no transform context arg.
            projector.setCrs(src_crs, dst_qgs_crs)

        block = projector.block(band_no, dst_extent_qgs, out_w, out_h)
        arr = self._decode_block(block, provider, band_no, out_w, out_h)

        dst_extent = Extent(
            dst_extent_qgs.xMinimum(), dst_extent_qgs.yMinimum(),
            dst_extent_qgs.xMaximum(), dst_extent_qgs.yMaximum(),
        )
        return arr, dst_extent

    def _decode_block(self, block, provider, band_no, out_w, out_h):
        """Shared block->float64-array-with-NaN-nodata decoding.

        Used by both the native and reprojected `read_band()` paths so
        nodata handling is identical either way. `provider.sourceNoDataValue`
        is queried from the *source* provider in both cases (that's what
        `QgsRasterProjector` reads through too), so the declared nodata
        value is still correctly recognised after reprojection.
        """
        has_nodata = provider.sourceHasNoDataValue(band_no)
        nodata_val = provider.sourceNoDataValue(band_no) if has_nodata else None

        arr = self._block_to_array(block, out_h, out_w)

        if has_nodata and nodata_val is not None:
            arr[np.isclose(arr, nodata_val, equal_nan=False)] = np.nan
        elif hasattr(block, "isNoData") and out_w * out_h <= 4_000_000:
            # No declared source nodata value, but QGIS may still flag
            # individual pixels as no-data (e.g. alpha/mask bands, or
            # pixels the projector could not map back into the source
            # raster at all).
            #
            # `isNoData(row, col)` has no bulk/vectorised equivalent in the
            # QGIS API, so a genuine per-pixel Python loop is the only way
            # to build the mask — but most blocks rendered here don't
            # actually contain any no-data pixels at all (masking only
            # matters at reprojection/resample edges). `hasNoData()` is a
            # cheap O(1) check the block already maintains, so we ask it
            # first and skip the O(width*height) loop entirely whenever it
            # says there's nothing to mask — this is the real-world common
            # case and the actual cost of that loop, not GPU/OpenCL, is
            # what made large single-band previews feel slow.
            try:
                block_has_any_nodata = True
                if hasattr(block, "hasNoData"):
                    block_has_any_nodata = bool(block.hasNoData())
                if block_has_any_nodata:
                    mask = np.zeros((out_h, out_w), dtype=bool)
                    for row in range(out_h):
                        for col in range(out_w):
                            if block.isNoData(row, col):
                                mask[row, col] = True
                    if mask.any():
                        arr[mask] = np.nan
            except Exception as exc:
                # Per-pixel isNoData() scan failed (e.g. an unusual block
                # type) — the array from _block_to_array() above is still
                # returned as-is, just without this extra masking pass.
                QgsMessageLog.logMessage(f"RasterViz: per-pixel nodata mask skipped: {exc}", "RasterViz", Qgis.Info)

        return arr

    @staticmethod
    def _block_to_array(block, out_h, out_w):
        """Decode a QgsRasterBlock into a float64 numpy array.

        Fast path: reinterpret the block's raw byte buffer with numpy
        (same bytes QGIS itself reads from GDAL). Falls back to
        `block.value(row, col)` — the historical, always-correct but
        slower approach — for any data type not in the fast-path table.
        """
        np_dtype = _QGIS_DTYPE_TO_NUMPY.get(block.dataType())
        if np_dtype is not None:
            try:
                raw = block.data()
                flat = np.frombuffer(bytes(raw), dtype=np_dtype)
                if flat.size == out_w * out_h:
                    return flat.reshape(out_h, out_w).astype(np.float64)
            except Exception as exc:
                # Fast-path buffer reinterpretation didn't line up (e.g. an
                # unexpected byte layout) — fall through to the slower but
                # always-correct block.value(row, col) path below instead
                # of failing outright.
                QgsMessageLog.logMessage(f"RasterViz: fast raster decode fell back to per-pixel: {exc}", "RasterViz", Qgis.Info)

        arr = np.empty((out_h, out_w), dtype=np.float64)
        for row in range(out_h):
            for col in range(out_w):
                arr[row, col] = block.value(row, col)
        return arr


class RasterRegistry:
    def __init__(self):
        self._layers = {}

    def mapLayers(self): return dict(self._layers)
    def mapLayer(self, layer_id): return self._layers.get(layer_id)
    def addMapLayer(self, layer):
        self._layers[layer.id()] = layer
        return layer
    def removeLayer(self, layer_id):
        self._layers.pop(layer_id, None)


RASTER_REGISTRY = RasterRegistry()

SUPPORTED_RASTER_FILTER = (
    "Raster Files (*.tif *.tiff *.geotiff *.img *.vrt *.nc *.hdf *.h5);;"
    "All Files (*)"
)
