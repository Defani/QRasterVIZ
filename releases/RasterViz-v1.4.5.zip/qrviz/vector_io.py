"""
vector_io.py — QGIS-native vector I/O and rendering for RasterViz.

Replaces the previous geopandas/fiona backend with QgsVectorLayer (QGIS's
own OGR provider), which reads Shapefile / GeoPackage / GeoJSON / KML(Z)
out of the box on every QGIS install. Because a QgsVectorLayer has no
`.plot()` method the way a GeoDataFrame does, rendering onto the plugin's
matplotlib Figure is implemented by hand below: geometries are pulled
through the QGIS API, reprojected with QgsCoordinateTransform if needed,
and drawn with matplotlib.patches / LineCollection / scatter.
"""

import os
import uuid

import matplotlib.patches as mpatches
from matplotlib.path import Path as MplPath
from matplotlib.collections import PatchCollection, LineCollection

from qgis.core import (
    QgsVectorLayer, QgsGeometry, QgsWkbTypes,
    QgsCoordinateTransform, QgsProject, QgsFeatureRequest, QgsSimplifyMethod,
    QgsMessageLog, Qgis,
)

DEFAULT_PALETTE = [
    "#e41a1c", "#377eb8", "#4daf4a", "#984ea3", "#ff7f00",
    "#a65628", "#f781bf", "#999999", "#ffff33", "#a6cee3",
    "#1f78b4", "#b2df8a", "#33a02c", "#fb9a99", "#fdbf6f",
    "#cab2d6", "#6a3d9a", "#ffff99", "#b15928", "#8dd3c7",
]

SUPPORTED_VECTOR_FILTER = (
    "Vector Files (*.shp *.gpkg *.geojson *.json *.kml *.kmz);;All Files (*)"
)


def crs_display_string(crs):
    """Short, human-readable label for a QgsCoordinateReferenceSystem."""
    if crs is None or not crs.isValid():
        return None
    return crs.authid() or crs.toProj()


def make_coordinate_transform(src_crs, dst_crs):
    """Build a QgsCoordinateTransform, or None if no reprojection is needed."""
    if src_crs is None or dst_crs is None:
        return None
    if not src_crs.isValid() or not dst_crs.isValid():
        return None
    if src_crs == dst_crs:
        return None
    return QgsCoordinateTransform(src_crs, dst_crs, QgsProject.instance())


class VectorLayer:
    """QGIS-native stand-in for the old geopandas-backed VectorLayer.

    Reads any OGR-supported vector file through QgsVectorLayer — no
    fiona/geopandas dependency needed. Styling attributes (fill/outline
    colors, categorized symbology, ...) are unchanged from before; only the
    storage/rendering engine changed.
    """

    def __init__(self, path):
        self.path = path
        self._id = str(uuid.uuid4())
        self._name = os.path.basename(path)
        self._valid = False
        self.error = None
        self.qgs_layer = None

        try:
            lyr = QgsVectorLayer(path, self._name, "ogr")
            if not lyr.isValid():
                raise RuntimeError(
                    "QGIS could not open this vector file with its OGR "
                    f"provider (unsupported/corrupt format?): {path}"
                )
            self.qgs_layer = lyr
            self._valid = True
        except Exception as exc:
            self.error = str(exc)

        self.symbology_mode = "single"
        self.fill_enabled = True
        self.fill_color = "#3388ff"
        self.fill_alpha = 0.55
        self.outline_color = "#1f1f1f"
        self.outline_width = 1.0
        self.category_field = None
        self.category_colors = {}

    # -- identity -----------------------------------------------------
    def isValid(self): return self._valid
    def id(self): return self._id
    def name(self): return self._name
    def error_message(self): return self.error

    def crs(self):
        return self.qgs_layer.crs() if self._valid else None

    def extent(self):
        return self.qgs_layer.extent() if self._valid else None

    def geometry_kind(self):
        """'point' | 'line' | 'polygon', based on the layer's WKB type."""
        if not self._valid:
            return "polygon"
        gtype = QgsWkbTypes.geometryType(self.qgs_layer.wkbType())
        if gtype == QgsWkbTypes.PointGeometry:
            return "point"
        if gtype == QgsWkbTypes.LineGeometry:
            return "line"
        return "polygon"

    # -- attributes / categorized symbology ----------------------------
    def field_names(self):
        if not self._valid:
            return []
        return list(self.qgs_layer.fields().names())

    def unique_values(self, field):
        if not self._valid:
            return []
        idx = self.qgs_layer.fields().indexOf(field)
        if idx < 0:
            return []
        vals = [v for v in self.qgs_layer.uniqueValues(idx) if v not in (None, "")]
        try:
            vals = sorted(vals)
        except TypeError:
            vals = sorted(vals, key=str)
        return vals

    def ensure_category_colors(self, field):
        for i, v in enumerate(self.unique_values(field)):
            if v not in self.category_colors:
                self.category_colors[v] = DEFAULT_PALETTE[i % len(DEFAULT_PALETTE)]

    # -- geometry access ------------------------------------------------
    def iter_features(self, dst_crs=None, extent=None, simplify_tolerance=None):
        """Yield (geometry_kind, rings_or_lines_or_points, attrs) per feature.

        This is the fast, QGIS-native path used for rendering large
        vector files (e.g. a nationwide administrative-boundary layer):
        filtering, reprojection and simplification are all pushed down
        into QgsFeatureRequest / the OGR provider (C++), instead of being
        done feature-by-feature in Python.

          - `extent` (QgsRectangle, in `dst_crs` if given, else the
            layer's own CRS): only features intersecting it are read —
            skips the rest of a country-wide layer when zoomed in.
          - `dst_crs` (QgsCoordinateReferenceSystem): reprojects every
            geometry before it reaches Python via
            QgsFeatureRequest.setDestinationCrs(), which is far cheaper
            than calling QgsGeometry.transform() per feature in a Python
            loop.
          - `simplify_tolerance` (float, in `dst_crs` map units): lets the
            provider generalize complex geometries (e.g. detailed
            coastlines) to roughly one vertex per this many map units —
            similar to QGIS's own "simplify for rendering" behaviour —
            so drawing stays smooth while zoomed out.

        Shapes returned per geometry kind (always in "multi" form,
        matching QGIS's own convertToMultiType()):
          - polygon: list of polygons; each polygon is a list of rings
            (ring 0 = exterior, rest = holes); each ring is a list of
            (x, y) tuples.
          - line: list of lines; each line is a list of (x, y) tuples.
          - point: list of (x, y) tuples.
        """
        if not self._valid:
            return
        kind = self.geometry_kind()
        field_names = self.field_names()

        request = QgsFeatureRequest()
        reprojected = False
        if dst_crs is not None and dst_crs.isValid() and self.qgs_layer.crs() != dst_crs:
            try:
                request.setDestinationCrs(dst_crs, QgsProject.instance().transformContext())
                reprojected = True
            except Exception:
                reprojected = False
        if extent is not None:
            try:
                request.setFilterRect(extent)
            except Exception as exc:
                # Spatial filter couldn't be applied (e.g. malformed
                # extent) — falls back to reading all features unfiltered,
                # so this is non-fatal but worth a log entry.
                QgsMessageLog.logMessage(f"RasterViz: vector filter rect not applied: {exc}", "RasterViz", Qgis.Info)
        if simplify_tolerance and simplify_tolerance > 0 and kind != "point":
            try:
                simp = QgsSimplifyMethod()
                simp.setMethodType(QgsSimplifyMethod.OptimizeForRendering)
                simp.setTolerance(simplify_tolerance)
                request.setSimplifyMethod(simp)
            except Exception as exc:
                # Simplification is a rendering-speed optimisation only —
                # geometries are still read at full detail if this fails.
                QgsMessageLog.logMessage(f"RasterViz: vector simplify method not applied: {exc}", "RasterViz", Qgis.Info)
        try:
            request.setSubsetOfAttributes(field_names, self.qgs_layer.fields())
        except Exception as exc:
            # Attribute subsetting is a read-speed optimisation only — all
            # attributes are still available if this fails.
            QgsMessageLog.logMessage(f"RasterViz: vector attribute subset not applied: {exc}", "RasterViz", Qgis.Info)

        # Only needed as a fallback for setDestinationCrs failing above
        # (e.g. very old PyQGIS API) — the common path never touches this.
        manual_transform = None
        if dst_crs is not None and not reprojected:
            manual_transform = make_coordinate_transform(self.qgs_layer.crs(), dst_crs)

        for feat in self.qgs_layer.getFeatures(request):
            geom = feat.geometry()
            if geom is None or geom.isEmpty():
                continue
            if manual_transform is not None:
                geom = QgsGeometry(geom)
                try:
                    geom.transform(manual_transform)
                except Exception as exc:
                    # This feature's geometry couldn't be reprojected (e.g.
                    # it falls outside the transform's valid area) — skip
                    # just this feature rather than drawing it in the
                    # wrong place or aborting the whole layer.
                    QgsMessageLog.logMessage(f"RasterViz: skipped a feature that failed to reproject: {exc}", "RasterViz", Qgis.Info)
                    continue
            else:
                geom = QgsGeometry(geom)  # copy — never mutate the feature's own geometry
            geom.convertToMultiType()
            attrs = {fn: feat.attribute(fn) for fn in field_names}

            if kind == "polygon":
                shape = [
                    [[(pt.x(), pt.y()) for pt in ring] for ring in poly]
                    for poly in geom.asMultiPolygon()
                ]
            elif kind == "line":
                shape = [
                    [(pt.x(), pt.y()) for pt in line]
                    for line in geom.asMultiPolyline()
                ]
            else:
                shape = [(pt.x(), pt.y()) for pt in geom.asMultiPoint()]

            if not shape:
                continue
            yield kind, shape, attrs


def _polygon_to_path(rings):
    """Build a matplotlib Path for one polygon (exterior + holes)."""
    verts, codes = [], []
    for ring in rings:
        if len(ring) < 3:
            continue
        verts.extend(ring)
        verts.append(ring[0])
        codes.append(MplPath.MOVETO)
        codes.extend([MplPath.LINETO] * (len(ring) - 1))
        codes.append(MplPath.CLOSEPOLY)
    if not verts:
        return None
    return MplPath(verts, codes)


def render_vector_layer(ax, vlayer, dst_crs=None, extent=None,
                         simplify_tolerance=None, layer_alpha=1.0,
                         fallback_color="#ff3333"):
    """Draw a VectorLayer onto a matplotlib Axes.

    This is the QGIS-native replacement for the old
    `gdf.plot(ax=ax, ...)` / `gdf.boundary.plot(...)` calls. It supports
    everything the previous geopandas renderer did: single-color fill and
    outline for polygons (with holes), line and point layers, and
    categorized symbology driven by `vlayer.category_field` /
    `vlayer.category_colors`.

    `dst_crs`, `extent` and `simplify_tolerance` are forwarded to
    `VectorLayer.iter_features()` so large layers (e.g. a nationwide
    boundary file) only cost as much as what's actually visible —
    reprojection, spatial filtering and generalization all happen inside
    QGIS's own feature-request pipeline rather than in this Python loop.
    """
    if vlayer is None or not vlayer.isValid():
        return

    features = list(vlayer.iter_features(
        dst_crs=dst_crs, extent=extent, simplify_tolerance=simplify_tolerance,
    ))
    if not features:
        return

    kind = features[0][0]
    categorized = (
        vlayer.symbology_mode == "categorized"
        and vlayer.category_field
        and vlayer.category_field in vlayer.field_names()
    )
    if categorized:
        vlayer.ensure_category_colors(vlayer.category_field)

    edge_color = vlayer.outline_color
    line_w = max(0.0, vlayer.outline_width)
    fill_alpha = max(0.0, min(1.0, vlayer.fill_alpha * layer_alpha))

    def color_for(attrs):
        if not categorized:
            return vlayer.fill_color
        val = attrs.get(vlayer.category_field)
        return vlayer.category_colors.get(val, edge_color)

    if kind == "polygon":
        patches, patch_colors = [], []
        for _, rings, attrs in features:
            for poly in rings:
                path = _polygon_to_path(poly)
                if path is None:
                    continue
                patches.append(mpatches.PathPatch(path))
                patch_colors.append(color_for(attrs))
        if not patches:
            return
        if vlayer.fill_enabled:
            fills = PatchCollection(
                patches, facecolors=patch_colors, edgecolors="none",
                alpha=fill_alpha, zorder=2,
            )
            ax.add_collection(fills)
        if line_w > 0:
            outline_colors = patch_colors if categorized else edge_color
            outlines = PatchCollection(
                patches, facecolors="none", edgecolors=outline_colors,
                linewidths=line_w, alpha=layer_alpha, zorder=3,
            )
            ax.add_collection(outlines)

    elif kind == "line":
        segments, colors = [], []
        for _, lines, attrs in features:
            c = color_for(attrs) if categorized else edge_color
            for line in lines:
                if len(line) >= 2:
                    segments.append(line)
                    colors.append(c)
        if not segments:
            return
        lc = LineCollection(
            segments, colors=colors, linewidths=max(line_w, 0.8),
            alpha=layer_alpha, zorder=3,
        )
        ax.add_collection(lc)

    else:  # point
        xs, ys, colors = [], [], []
        for _, pts, attrs in features:
            c = color_for(attrs) if categorized else edge_color
            for x, y in pts:
                xs.append(x); ys.append(y); colors.append(c)
        if not xs:
            return
        size = max(12.0, line_w * 8)
        ax.scatter(xs, ys, c=colors, s=size, alpha=layer_alpha, zorder=4,
                   edgecolors="none")
