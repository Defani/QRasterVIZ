# RasterViz v2 — Layout-native method

> **Status: pending QGIS Plugin Repository approval — install via ZIP
> for now.** This is RasterViz v2 (the Layout-native method),
> currently awaiting review and not yet on the official
> plugins.qgis.org listing — so it can't be found or installed through
> **Plugins → Manage and Install Plugins → All** yet. Until it's
> approved, grab the `.zip` and use **Install from ZIP** (see
> Installation below). The listing still serves the classic
> dialog-based **RasterViz v1 (1.4.5)** in the meantime — see its own
> README.

A QGIS plugin that adds a Layout item for producing a matplotlib-style
colour stretch bar (colorbar), linked live to a raster layer's own
symbology. Built for the QGIS **Print Layout / Layout Designer** — no
separate window, no external dependencies.

## Not a replacement — a different method

RasterViz v1 (1.x, still the version live on the plugin repository as
1.4.5) opens its **own separate window** — a standalone Matplotlib-
based dialog with a colormap gallery, RGB composite, web basemaps,
discrete classification, and a single-window PNG/SVG/TIFF/PDF export
step.

RasterViz v2 doesn't try to replace that. It's a different method
entirely: the plugin adds its own item straight into the **Layout
Designer**, exactly alongside Legend, Scale Bar or Picture, so a
scientific-style colorbar can sit natively in a Print Layout next to
QGIS's own native North Arrow, Scale Bar, Grid and Legend items —
instead of a separate matplotlib canvas and its own export step:

- It's added from the Layout Designer's own **Add Item** toolbar/menu.
- All of its settings are edited in a dedicated **"RasterViz"
  dock panel**, docked into the Layout window automatically (next to
  QGIS's own Items / Undo History panels) — not in a popup dialog,
  and not buried in the generic Item Properties tab.
- Once added, it behaves like any other layout item: drag, resize,
  align, group, export with the rest of the layout, save/reload with
  the project.

No Matplotlib, no extra window to manage, no export step of its own —
it's just another item on the page. Reach for RasterViz v1 (the
classic dialog) instead when you need its colormap gallery, RGB
composite, basemaps, or discrete classification — v2 is specifically
for when a scientific-style colorbar needs to live directly inside a
native Print Layout.

## Features

- Reads colours and the value range **live** from the linked raster
  layer's own Symbology (Singleband pseudocolor or Singleband gray).
  Change that layer's colour ramp or Min/Max on the canvas and the
  colorbar updates on its own.
- Colour ramp is picked from QGIS's own built-in "Raster colour ramp"
  picker (QgsColorRampButton) — no custom/bundled palettes of the
  plugin's own to keep in sync.
- Continuous (smooth gradient) or discrete (stepped, with a tick at
  every block boundary) bar style.
- Horizontal or vertical orientation, with direct Width/Height (mm)
  fields — what you type is what the bar draws at.
- Box, pointed ("extend"), or both-pointed end styles, with optional
  rounded corners.
- Configurable number of sampled colours (2–256) and reverse colour
  order.
- Configurable tick count, decimals, inside/outside position, padding,
  and font (size/bold/italic).
- Optional axis label, with its own padding and font.
- Independent colour pickers and font-family choice for tick numbers
  and the axis label (in addition to size/bold/italic), for placing
  the bar over any background.

## Installation

Not on plugins.qgis.org yet (still pending approval), so it won't show
up under **Plugins → Manage and Install Plugins → All** — install it
manually from the ZIP instead:

1. Download the plugin `.zip`.
2. In QGIS: **Plugins → Manage and Install Plugins → Install from ZIP**,
   point it at the downloaded file, and click **Install Plugin**.
3. Open a Print Layout. The **"RasterViz"** panel appears
   automatically on the right — if it's hidden, re-enable it from the
   Layout window's **Panels** menu.

Once v2 clears review, it'll be installable the normal way too, same
as v1.4.5 is today.

## Usage

1. Open (or create) a Print Layout.
2. In the **RasterViz** panel, click **+ Add Colorbar** (shown
   whenever no colorbar item is selected).
3. Select the item on the canvas — its settings load into the panel.
4. Pick a raster layer, set orientation/size/style, and adjust ticks
   and label as needed.

## Dependencies

None. Pure PyQGIS + PyQt5 — see `requirements.txt`.

## License

GNU GPL v2 or later — see `LICENSE`.

## Links

- Repository / issue tracker: https://github.com/Defani/QRasterVIZ
