"""
raster_io.py — QGIS-native raster I/O layer for RasterViz.

This used to be backed by rasterio. It is now backed entirely by QGIS's own
API (QgsRasterLayer + QgsRasterDataProvider.block()), which is bundled with
every QGIS installation and reads the same GDAL formats rasterio does
(GeoTIFF, IMG, VRT, NetCDF, HDF, ...). No third-party package is required
for raster support any more.

The public interface (RasterLayer.isValid/id/name/bandCount/width/height/
extent/crs/read_band, plus RASTER_REGISTRY and SUPPORTED_RASTER_FILTER) is
unchanged, so dialog.py does not need to know the backend changed.
"""

import os
import uuid
import numpy as np

from qgis.core import QgsRasterLayer, Qgis


class Extent:
    """Minimal stand-in for qgis.core.QgsRectangle (read-only bounds)."""
    __slots__ = ("_xmin", "_ymin", "_xmax", "_ymax")

    def __init__(self, xmin, ymin, xmax, ymax):
        self._xmin, self._ymin, self._xmax, self._ymax = xmin, ymin, xmax, ymax

    def xMinimum(self): return self._xmin
    def xMaximum(self): return self._xmax
    def yMinimum(self): return self._ymin
    def yMaximum(self): return self._ymax


# Qgis.DataType (raster block sample type) -> numpy dtype, for the fast
# buffer-decoding path in read_band(). Complex types are intentionally left
# out; they fall back to the value-by-value path below, since none of
# RasterViz's rendering modes (single-band, discrete, RGB) use complex data.
#
# QGIS >=3.36 exposes these as Qgis.DataType.Byte (a proper Python enum);
# older 3.x releases only have the flat Qgis.Byte constants. Both spellings
# are tried so this works across the whole 3.0-3.99 range declared in
# metadata.txt.
def _dtype_enum(name):
    dt = getattr(Qgis, "DataType", None)
    if dt is not None and hasattr(dt, name):
        return getattr(dt, name)
    return getattr(Qgis, name, None)


_QGIS_DTYPE_TO_NUMPY = {
    v: np_t for v, np_t in (
        (_dtype_enum("Byte"), np.uint8),
        (_dtype_enum("UInt16"), np.uint16),
        (_dtype_enum("Int16"), np.int16),
        (_dtype_enum("UInt32"), np.uint32),
        (_dtype_enum("Int32"), np.int32),
        (_dtype_enum("Float32"), np.float32),
        (_dtype_enum("Float64"), np.float64),
    ) if v is not None
}


class RasterLayer:
    """Minimal stand-in for qgis.core.QgsRasterLayer, backed by QGIS itself."""

    def __init__(self, path, display_name=None):
        self.path = path
        self._id = str(uuid.uuid4())
        self._name = display_name or os.path.basename(path)
        self._valid = False
        self._width = 0
        self._height = 0
        self._band_count = 0
        self._extent = None
        self._crs = None
        self._error = None
        self._qgs_layer = None

        try:
            lyr = QgsRasterLayer(path, self._name, "gdal")
            if not lyr.isValid():
                raise RuntimeError(
                    "QGIS could not open this raster with its GDAL provider "
                    f"(unsupported/corrupt format?): {path}"
                )
            self._qgs_layer = lyr
            self._width = lyr.width()
            self._height = lyr.height()
            self._band_count = lyr.bandCount()
            e = lyr.extent()
            self._extent = Extent(e.xMinimum(), e.yMinimum(), e.xMaximum(), e.yMaximum())
            self._crs = lyr.crs().authid() or None
            self._valid = True
        except Exception as exc:
            self._error = str(exc)
            self._valid = False

    def isValid(self): return self._valid
    def id(self): return self._id
    def name(self): return self._name
    def bandCount(self): return self._band_count
    def width(self): return self._width
    def height(self): return self._height
    def extent(self): return self._extent
    def crs(self): return self._crs
    def error_message(self): return self._error

    def read_band(self, band_no, max_px_k=1000):
        """Read one band, resampled to at most max_px_k*1000 pixels.

        Returns (numpy_float64_array_with_nan_nodata, Extent). This mirrors
        the plugin's original QGIS-native `_read_band` helper: it goes
        through `provider.block(band_no, extent, width, height)` and uses
        `provider.sourceNoDataValue`/`sourceHasNoDataValue` to mask nodata.
        """
        max_px = max_px_k * 1000
        total_px = self._width * self._height
        out_w, out_h = self._width, self._height
        if total_px > max_px and total_px > 0:
            scale = (max_px / total_px) ** 0.5
            out_w = max(1, int(self._width * scale))
            out_h = max(1, int(self._height * scale))

        provider = self._qgs_layer.dataProvider()
        qgs_extent = self._qgs_layer.extent()
        block = provider.block(band_no, qgs_extent, out_w, out_h)

        has_nodata = provider.sourceHasNoDataValue(band_no)
        nodata_val = provider.sourceNoDataValue(band_no) if has_nodata else None

        arr = self._block_to_array(block, out_h, out_w)

        if has_nodata and nodata_val is not None:
            arr[np.isclose(arr, nodata_val, equal_nan=False)] = np.nan
        elif hasattr(block, "isNoData") and out_w * out_h <= 4_000_000:
            # No declared source nodata value, but QGIS may still flag
            # individual pixels as no-data (e.g. alpha/mask bands). Only
            # worth the per-pixel check on the smaller, already-downsampled
            # blocks this method returns.
            try:
                mask = np.zeros((out_h, out_w), dtype=bool)
                for row in range(out_h):
                    for col in range(out_w):
                        if block.isNoData(row, col):
                            mask[row, col] = True
                if mask.any():
                    arr[mask] = np.nan
            except Exception:
                pass

        return arr, self._extent

    @staticmethod
    def _block_to_array(block, out_h, out_w):
        """Decode a QgsRasterBlock into a float64 numpy array.

        Fast path: reinterpret the block's raw byte buffer with numpy
        (same bytes QGIS itself reads from GDAL). Falls back to
        `block.value(row, col)` — the historical, always-correct but
        slower approach — for any data type not in the fast-path table.
        """
        np_dtype = _QGIS_DTYPE_TO_NUMPY.get(block.dataType())
        if np_dtype is not None:
            try:
                raw = block.data()
                flat = np.frombuffer(bytes(raw), dtype=np_dtype)
                if flat.size == out_w * out_h:
                    return flat.reshape(out_h, out_w).astype(np.float64)
            except Exception:
                pass  # fall through to the slow-but-safe path below

        arr = np.empty((out_h, out_w), dtype=np.float64)
        for row in range(out_h):
            for col in range(out_w):
                arr[row, col] = block.value(row, col)
        return arr


class RasterRegistry:
    def __init__(self):
        self._layers = {}

    def mapLayers(self): return dict(self._layers)
    def mapLayer(self, layer_id): return self._layers.get(layer_id)
    def addMapLayer(self, layer):
        self._layers[layer.id()] = layer
        return layer
    def removeLayer(self, layer_id):
        self._layers.pop(layer_id, None)


RASTER_REGISTRY = RasterRegistry()

SUPPORTED_RASTER_FILTER = (
    "Raster Files (*.tif *.tiff *.geotiff *.img *.vrt *.nc *.hdf *.h5);;"
    "All Files (*)"
)
