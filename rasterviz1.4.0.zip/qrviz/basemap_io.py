"""
basemap_io.py — 100% QGIS-native web basemap engine for RasterViz.

Replaces the old contextily-based basemap fetch. Instead of a third-party
tile-stitching library, this builds a native QgsRasterLayer XYZ connection
(the exact same URI scheme QuickMapServices uses for its "TMS" layers) and
renders it through QGIS's own map-render pipeline (QgsMapSettings +
QgsMapRendererCustomPainterJob). Letting QGIS do the fetch/stitch/reproject
means basemap alignment against the raster/vector layers on top of it is
guaranteed to match — it's the same renderer QGIS uses for its own canvas.

No pip packages required.
"""

import numpy as np

from qgis.core import (
    QgsRasterLayer,
    QgsMapSettings,
    QgsMapRendererCustomPainterJob,
    QgsCoordinateReferenceSystem,
    QgsRectangle,
    QgsProject,
)
from qgis.PyQt.QtCore import QSize
from qgis.PyQt.QtGui import QImage, QPainter, QColor


def _encode_tms_url(url_template):
    """Percent-encode '=' and '&' inside the tile URL template so QGIS's
    'type=xyz&...&url=<here>' connection string parses it as a single
    opaque value instead of extra key=value pairs. This is exactly what
    QuickMapServices does for its own TMS layers."""
    return url_template.replace("=", "%3D").replace("&", "%26")


def build_xyz_layer(url_template, name, zmax, zmin=0):
    """Build a native QgsRasterLayer XYZ connection from a {z}/{x}/{y} (or
    {z}/{y}/{x}) tile URL template — no third-party package involved.

    :param url_template: tile URL containing {z}, {x}, {y} placeholders
        (and optionally {-y} for TMS-style flipped Y, handled upstream if
        ever needed).
    :param name: display name for the layer.
    :param zmax: maximum zoom level the provider serves.
    :param zmin: minimum zoom level (default 0).
    :return: QgsRasterLayer (check .isValid() before using).
    """
    encoded_url = _encode_tms_url(url_template)
    uri = "type=xyz&zmin={0}&zmax={1}&url={2}".format(zmin, zmax, encoded_url)
    layer = QgsRasterLayer(uri, name, "wms")
    # Slippy-map XYZ tiles are always served in Web Mercator; QGIS's own
    # XYZ/QMS layers default to this too (see QuickMapServices'
    # set_tile_layer_proj, which starts from the same EPSG:3857 default).
    layer.setCrs(QgsCoordinateReferenceSystem.fromEpsgId(3857))
    return layer


def _qimage_to_rgba(qimg):
    """Convert a QImage (ARGB32_Premultiplied) to an (H, W, 4) uint8 RGBA
    numpy array, with no extra dependency beyond numpy.

    ARGB32_Premultiplied stores each pixel, little-endian, as bytes
    [B, G, R, A] with R/G/B already multiplied by A/255 ("premultiplied").
    imshow() expects straight (non-premultiplied) RGBA, so every channel
    is un-premultiplied by dividing back out the alpha — otherwise colors
    look darkened/muddy near any transparent edge.
    """
    qimg = qimg.convertToFormat(QImage.Format_ARGB32_Premultiplied)
    w, h = qimg.width(), qimg.height()

    ptr = qimg.bits()
    try:
        nbytes = qimg.sizeInBytes()
    except AttributeError:
        nbytes = qimg.byteCount()
    ptr.setsize(nbytes)

    stride_px = qimg.bytesPerLine() // 4
    buf = np.frombuffer(ptr, dtype=np.uint8).reshape((h, stride_px, 4))
    buf = buf[:, :w, :]  # drop any row padding beyond the real width

    b = buf[:, :, 0].astype(np.float32)
    g = buf[:, :, 1].astype(np.float32)
    r = buf[:, :, 2].astype(np.float32)
    a = buf[:, :, 3].astype(np.float32)

    alpha_safe = np.where(a == 0, 1.0, a)
    r_un = np.clip(r * 255.0 / alpha_safe, 0, 255)
    g_un = np.clip(g * 255.0 / alpha_safe, 0, 255)
    b_un = np.clip(b * 255.0 / alpha_safe, 0, 255)

    return np.dstack([r_un, g_un, b_un, a]).astype(np.uint8)


def render_basemap_to_array(url_template, zmax, target_crs, extent, out_w, out_h, zmin=0):
    """Render an XYZ basemap into the given CRS/extent using QGIS's own
    map-render job — no manual tile warping/reprojection is done here;
    QGIS reprojects the tiles exactly as it would drawing them on its own
    canvas, so alignment against other layers on the same view is exact
    (including into non-3857 CRS like UTM).

    :param url_template: tile URL template ({z}/{x}/{y} placeholders).
    :param zmax: provider's max zoom level.
    :param target_crs: QgsCoordinateReferenceSystem, or a string QGIS can
        parse (e.g. "EPSG:32748"), matching the CRS the rest of the figure
        is being drawn in.
    :param extent: (xmin, xmax, ymin, ymax) in target_crs units — this is
        the same order matplotlib's ax.get_xlim() + ax.get_ylim() gives.
    :param out_w: output image width in pixels.
    :param out_h: output image height in pixels.
    :param zmin: provider's min zoom level (default 0).
    :return: (rgba_array, imshow_extent) where rgba_array is an
        (out_h, out_w, 4) uint8 numpy array ready for
        ax.imshow(rgba_array, extent=imshow_extent, origin='upper'), and
        imshow_extent is [xmin, xmax, ymin, ymax].
    """
    if not isinstance(target_crs, QgsCoordinateReferenceSystem):
        target_crs = QgsCoordinateReferenceSystem(str(target_crs))
    if not target_crs.isValid():
        raise RuntimeError("basemap_io: invalid target CRS for basemap rendering")

    xmin, xmax, ymin, ymax = extent
    map_extent = QgsRectangle(xmin, ymin, xmax, ymax)

    layer = build_xyz_layer(url_template, "_qrviz_basemap_tmp", zmax, zmin=zmin)
    if not layer.isValid():
        raise RuntimeError("basemap_io: failed to create XYZ basemap layer (check URL/network)")

    out_w = max(1, int(out_w))
    out_h = max(1, int(out_h))

    settings = QgsMapSettings()
    settings.setLayers([layer])
    settings.setDestinationCrs(target_crs)
    settings.setExtent(map_extent)
    settings.setOutputSize(QSize(out_w, out_h))
    settings.setBackgroundColor(QColor(0, 0, 0, 0))
    settings.setOutputDpi(96)
    try:
        settings.setTransformContext(QgsProject.instance().transformContext())
    except Exception:
        pass

    image = QImage(out_w, out_h, QImage.Format_ARGB32_Premultiplied)
    image.fill(0)  # fully transparent background

    painter = QPainter(image)
    job = QgsMapRendererCustomPainterJob(settings, painter)
    # Synchronous on purpose: this runs inside _live_update() on the main
    # thread during figure render, same as the old contextily call did.
    job.start()
    job.waitForFinished()
    painter.end()

    rgba = _qimage_to_rgba(image)
    imshow_extent = [xmin, xmax, ymin, ymax]
    return rgba, imshow_extent
