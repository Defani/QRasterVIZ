"""
icons.py — Lightweight, dependency-free icon provider for RasterViz.

Replaces qtawesome. Icons are small hand-drawn line-glyph SVGs rendered
through Qt's own QSvgRenderer (part of every Qt/QGIS install) and tinted to
match the active Qt/QGIS palette by default, so they look correct in every
QGIS colour theme without a custom stylesheet and without any third-party
package.
"""

from qgis.PyQt.QtCore import Qt, QByteArray, QRectF
from qgis.PyQt.QtGui import QIcon, QPixmap, QPainter, QGuiApplication, QPalette
from qgis.PyQt.QtSvg import QSvgRenderer

# Each entry is an SVG <path> "d" attribute drawn on a 24x24 viewBox.
_GLYPHS = {
    "sun": "M12 4V2M12 22v-2M4 12H2M22 12h-2M5.6 5.6 4.2 4.2M19.8 19.8l-1.4-1.4"
           "M5.6 18.4l-1.4 1.4M19.8 4.2l-1.4 1.4M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10Z",
    "moon": "M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5Z",
    "github": "M12 2C6.48 2 2 6.58 2 12.25c0 4.53 2.87 8.37 6.84 9.73.5.1.68-.22."
              "68-.5v-1.94c-2.78.62-3.37-1.37-3.37-1.37-.46-1.2-1.11-1.52-1.11-"
              "1.52-.9-.63.07-.62.07-.62 1 .07 1.53 1.05 1.53 1.05.9 1.57 2.34 "
              "1.12 2.91.86.09-.67.35-1.12.64-1.38-2.22-.26-4.56-1.14-4.56-5.06 "
              "0-1.12.39-2.03 1.03-2.75-.1-.26-.45-1.3.1-2.72 0 0 .84-.28 2.75 "
              "1.05A9.3 9.3 0 0 1 12 6.8c.85 0 1.71.12 2.51.34 1.9-1.33 2.75-"
              "1.05 2.75-1.05.55 1.42.2 2.46.1 2.72.64.72 1.03 1.63 1.03 2.75 0 "
              "3.93-2.34 4.79-4.57 5.05.36.32.68.94.68 1.9v2.82c0 .28.18.6.69.5"
              "A10.26 10.26 0 0 0 22 12.25C22 6.58 17.52 2 12 2Z",
    "grid": "M4 4h6v6H4V4Zm10 0h6v6h-6V4ZM4 14h6v6H4v-6Zm10 0h6v6h-6v-6Z",
    "polygon": "M12 3 3 9l3.5 11h11L21 9 12 3Z",
    "trash": "M6 7h12M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2m-8 0h10l-1 13H8L7 7Z",
    "play": "M7 4.5v15l13-7.5-13-7.5Z",
    "list": "M4 6h2M4 12h2M4 18h2M9 6h11M9 12h11M9 18h11",
    "chevron_left": "M15 4 7 12l8 8",
    "chevron_right": "M9 4l8 8-8 8",
    "expand": "M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5",
    "zoom_in": "M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14Zm10 17-5.6-5.6M11 8v6M8 11h6",
    "zoom_out": "M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14Zm10 17-5.6-5.6M8 11h6",
    "globe": "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm0 0c2.5 2.7 3.8 6.1 3.8 "
             "10s-1.3 7.3-3.8 10M12 2C9.5 4.7 8.2 8.1 8.2 12S9.5 19.3 12 22"
             "M2.5 9h19M2.5 15h19",
    "sliders": "M4 6h9m3 0h4M4 12h4m3 0h9M4 18h13m3 0h0M13 6a2 2 0 1 0 4 0 2 2 0 "
               "0 0-4 0Zm-6 6a2 2 0 1 0 4 0 2 2 0 0 0-4 0Zm10 6a2 2 0 1 0 4 0 2 2 "
               "0 0 0-4 0Z",
    "font": "M6 20 10.5 4h2L17 20M7.6 14h7.8",
    "map": "M9 3 4 5v16l5-2 6 2 5-2V3l-5 2-6-2Zm0 0v16m6-14v16",
    "legend": "M4 5h6v6H4V5Zm0 8h6v6H4v-6Zm10-8h6M14 8h6M14 15h6M14 19h6",
    "chart": "M4 20V10m6 10V4m6 16v-7m6 7V8",
    "table": "M3 4h18v16H3V4Zm0 6h18M9 4v16",
    "export": "M12 3v12m0-12 4 4m-4-4-4 4M4 15v4a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-4",
    "check_circle": "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm-2 11 3 3 5-6",
    "spinner": "M12 3v3m0 12v3m9-9h-3M6 12H3m14.4-6.4-2.1 2.1M8.7 15.3l-2.1 2.1m0"
               "-10.8 2.1 2.1m8.6 8.6-2.1-2.1",
    "error_circle": "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm0 6v6m0 4h.01",
}

# Maps the qtawesome-style dotted names previously used across dialog.py to
# our lightweight glyph keys, so existing call sites keep working unchanged.
_ALIASES = {
    "fa5s.sun": "sun", "fa5s.moon": "moon", "fa5b.github": "github",
    "mdi.checkerboard": "grid", "fa5s.draw-polygon": "polygon",
    "fa5s.trash-alt": "trash", "fa5s.play": "play", "fa5s.list-ol": "list",
    "fa5s.chevron-left": "chevron_left", "fa5s.chevron-right": "chevron_right",
    "fa5s.expand": "expand", "fa5s.search-plus": "zoom_in",
    "fa5s.search-minus": "zoom_out", "fa5s.globe-asia": "globe",
    "fa5s.sliders-h": "sliders", "fa5s.font": "font",
    "fa5s.map-marked-alt": "map", "mdi.map-legend": "legend",
    "fa5s.chart-line": "chart", "fa5s.th-large": "table",
    "fa5s.file-export": "export", "fa5s.check-circle": "check_circle",
    "fa5s.spinner": "spinner", "fa5s.exclamation-circle": "error_circle",
}

_SVG_TEMPLATE = (
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">'
    '<path d="{d}" fill="none" stroke="{color}" stroke-width="1.8" '
    'stroke-linecap="round" stroke-linejoin="round"/></svg>'
)

_cache = {}


def _default_color():
    """Fall back to the active Qt/QGIS palette's text colour."""
    app = QGuiApplication.instance()
    if app is not None:
        try:
            return app.palette().color(QPalette.WindowText).name()
        except Exception:
            pass
    return "#202124"


def make_icon(name, color=None, size=16):
    """Render a small line-icon as a QIcon.

    `name` accepts either an internal glyph key ("sun", "grid", ...) or one
    of the qtawesome-style dotted names ("fa5s.sun", "mdi.checkerboard",
    ...) that were used throughout the plugin before the qtawesome
    dependency was removed, so old call sites keep working unchanged.
    Unknown names fall back to a generic grid glyph instead of raising, and
    the result is always a valid QIcon (never None), so callers no longer
    need an "is icon library available" check.
    """
    key = _ALIASES.get(name, name)
    d = _GLYPHS.get(key, _GLYPHS["grid"])
    col = color or _default_color()

    cache_key = (key, col, size)
    cached = _cache.get(cache_key)
    if cached is not None:
        return cached

    svg = _SVG_TEMPLATE.format(d=d, color=col)
    renderer = QSvgRenderer(QByteArray(svg.encode("utf-8")))
    dpr = 2  # a little HiDPI headroom
    pm = QPixmap(size * dpr, size * dpr)
    pm.fill(Qt.transparent)
    painter = QPainter(pm)
    renderer.render(painter, QRectF(0, 0, size * dpr, size * dpr))
    painter.end()
    pm.setDevicePixelRatio(dpr)

    icon = QIcon(pm)
    _cache[cache_key] = icon
    return icon
